// =========================================================================
//  BYPASS SCRIPT — HARUS di-load PALING AWAL
//  (FINAL: Safe Mode + Auto Re-Bypass Per Match)
// =========================================================================
const char* myBypassLuaScript = R"Ultimate_LUA_END(
-- =====================================================================
--  AK BYPASS — FINAL VERSION
--  Strategi: Lua-level spoof only (NO network blocking)
--  Auto re-install setiap masuk match baru
-- =====================================================================

-- ================================================================
-- SECTION 1-8: BASE BYPASS
-- ================================================================
local function _AK_InstallBypass()
    -- 1. Skin & download reporting
    pcall(function()
        local puffer_tlog = package.loaded["client.slua.logic.download.report.puffer_tlog"]
        if puffer_tlog then
            puffer_tlog.ReportEvent          = function() end
            puffer_tlog.ReportDownloadResult = function() end
            puffer_tlog.ReportODPTDError     = function() end
        end
        local AvatarUtils = package.loaded["AvatarUtils"]
        if AvatarUtils then
            AvatarUtils.CheckIsWeaponInBlackList = function() return false end
            AvatarUtils.IsValidAvatar            = function() return true  end
        end
        local SubsystemMgr = require("GameLua.GameCore.Module.Subsystem.SubsystemMgr")
        local fileCheckSubsystem = SubsystemMgr:Get("FileCheckSubsystem")
        if fileCheckSubsystem then
            fileCheckSubsystem.StartCheck         = function() end
            fileCheckSubsystem.ReportAbnormalFile = function() end
        end
        local equipmentException = package.loaded["client.slua.logic.report.EquipmentExceptionReport"]
        if equipmentException then equipmentException.Report = function() end end
    end)

    -- 2. Log & telemetry blocking
    pcall(function()
        local ScreenshotMTDer = import("ScreenshotMTDer")
        if ScreenshotMTDer then
            ScreenshotMTDer.MTDePicture   = function() return "" end
            ScreenshotMTDer.ReMTDePicture = function() return "" end
            ScreenshotMTDer.HasCaptured   = function() return true end
        end
        local TLog = package.loaded["TLog"] or _G.TLog
        if TLog then
            TLog.Info = function() end; TLog.Warning = function() end
            TLog.Error = function() end; TLog.Debug = function() end
            TLog.Report = function() end
        end
        local CrashSight = package.loaded["CrashSight"] or _G.CrashSight
        if CrashSight then
            CrashSight.ReportException = function() end
            CrashSight.SetCustomData   = function() end
            CrashSight.Log             = function() end
        end
        local GameReportUtils = package.loaded["GameLua.Mod.BaseMod.GamePlay.GameReport.GameReportUtils"]
        if GameReportUtils then
            GameReportUtils.BugglyPostExceptionFull     = function() return false end
            GameReportUtils.CheckCanBugglyPostException = function() return false end
            GameReportUtils.ReplayReportData            = function() end
            GameReportUtils.ReportGameException         = function() end
        end
        local ClientToolsReport = package.loaded["client.slua.logic.report.ClientToolsReport"]
        if ClientToolsReport then
            ClientToolsReport.SendReport    = function() end
            ClientToolsReport.SendException = function() end
        end
        local TLogReportUtils = package.loaded["client.slua.config.tlog.tlog_report_utils"]
        if TLogReportUtils then TLogReportUtils.ReportTLogEvent = function() end end
        local ClientTLogUtil = package.loaded["GameLua.Mod.BaseMod.Client.ClientTLog.ClientTLogUtil"]
        if ClientTLogUtil then
            ClientTLogUtil.ReportGeneralCountByBRPhase   = function() end
            ClientTLogUtil.ReportCommonTLogDataByBRPhase = function() end
        end
    end)

    -- 3. Scanner / avatarexception
    pcall(function()
        local SubsystemMgr = require("GameLua.GameCore.Module.Subsystem.SubsystemMgr")
        if SubsystemMgr then
            local AFKReportor = SubsystemMgr:Get("AFKReportorSubsystem")
            if AFKReportor then
                AFKReportor.PlayerHaveAction = function() end
                AFKReportor.ReportAFK        = function() end
            end
            local DataStatistcs = SubsystemMgr:Get("ClientDataStatistcsSubsystem")
            if DataStatistcs then
                DataStatistcs.StartToCheck = function() end
                DataStatistcs.DelayCount   = 0
            end
            local AvatarException = SubsystemMgr:Get("AvatarExceptionSubsystem")
            if AvatarException then
                AvatarException.ReportException     = function() end
                AvatarException.BindPlayerCharacter = function() end
                AvatarException.CheckAvatarValid    = function() return true end
            end
            local ShootVerify = SubsystemMgr:Get("ShootVerifySubSystemClient")
            if ShootVerify then
                ShootVerify.ReportVerifyFail = function() end
                ShootVerify.OnVerifyFailed   = function() end
            end
        end
        local CreativeModeBlueprintLibrary = import("CreativeModeBlueprintLibrary")
        if CreativeModeBlueprintLibrary then
            CreativeModeBlueprintLibrary.MD5HashByteArray   = function() return "BYPASSED_MD5_HASH" end
            CreativeModeBlueprintLibrary.GetContentDiffData = function() return true, "BYPASSED" end
        end
        local AvatarExceptionPlayerInst = package.loaded["GameLua.Mod.Library.GamePlay.Avatar.Exception.AvatarExceptionPlayerInst"]
        if AvatarExceptionPlayerInst then
            AvatarExceptionPlayerInst.CheckAvatarException        = function() end
            AvatarExceptionPlayerInst.CheckAvatarExceptionOnce    = function() end
            AvatarExceptionPlayerInst.ReportAvatarException       = function() end
            AvatarExceptionPlayerInst.CheckSlotMeshVisible        = function() return false end
            AvatarExceptionPlayerInst.CheckPawnVisible            = function() return false end
            AvatarExceptionPlayerInst.CheckCanBugglyPostException = function() return false end
        end
        local AvatarCheckerModule = package.loaded["blacklist.slua.logic.lobby_gm.AvatarCheckerModule"]
        if AvatarCheckerModule then
            AvatarCheckerModule.CheckAvatar     = function() return true end
            AvatarCheckerModule.ReportException = function() end
        end
        local logic_memory_warning = package.loaded["client.slua.logic.memory_warning.logic_memory_warning"]
        if logic_memory_warning then
            logic_memory_warning.OnMemoryWarning     = function() end
            logic_memory_warning.ReportMemoryWarning = function() end
        end
        local TssSdk = package.loaded["TssSdk"] or _G.TssSdk
        if TssSdk then
            TssSdk.SendReportInfo      = function() end
            TssSdk.ScanMemory          = function() return true  end
            TssSdk.IsEmulator          = function() return false end
            TssSdk.GetTssSdkReportInfo = function() return ""    end
        end
    end)

    -- 4. Replay & telemetry subsystems
    pcall(function()
        local SubsystemMgr = require("GameLua.GameCore.Module.Subsystem.SubsystemMgr")
        local RescueBtnReplayTraceSubsystem = SubsystemMgr and SubsystemMgr:Get("RescueBtnReplayTraceSubsystem")
        if RescueBtnReplayTraceSubsystem then
            RescueBtnReplayTraceSubsystem.ReportTrace                = function() end
            RescueBtnReplayTraceSubsystem.StartTickMonitor           = function() end
            RescueBtnReplayTraceSubsystem.TickMonitorCheck           = function() end
            RescueBtnReplayTraceSubsystem.ReportTickMonitorHeartbeat = function() end
        end
        local GameReportSubsystem = SubsystemMgr and SubsystemMgr:Get("GameReportSubsystem")
        if GameReportSubsystem then
            GameReportSubsystem.ReplayReportData            = function() return false end
            GameReportSubsystem.CheckCanBugglyPostException = function() return false end
            GameReportSubsystem.BugglyPostExceptionFull     = function() return false end
            GameReportSubsystem.GetClientReplayDataReporter = function() return nil   end
            if GameReportSubsystem.Reporter then
                GameReportSubsystem.Reporter.ReportIntArrayData   = function() end
                GameReportSubsystem.Reporter.ReportUInt8ArrayData = function() end
                GameReportSubsystem.Reporter.ReportFloatArrayData = function() end
            end
        end
        local logic_report_replay = package.loaded["client.slua.logic.replay.logic_report_replay"]
        if logic_report_replay then
            logic_report_replay.ReportReplay  = function() end
            logic_report_replay.SendReportReq = function() end
        end
        local logic_home_report = package.loaded["client.slua.logic.home.logic_home_report"]
        if logic_home_report then
            logic_home_report.ShowInGameReportUI = function() end
            logic_home_report.SendReport         = function() end
        end
    end)

    -- 5. Higgs Boson disable
    pcall(function()
        local PC = slua_GameFrontendHUD and slua_GameFrontendHUD:GetPlayerController()
        if PC and slua.isValid(PC) then
            if PC.HiggsBoson then
                PC.HiggsBoson.bMHActive           = false
                PC.HiggsBoson.bCallPreReplication = false
            end
            if PC.HiggsBosonComponent then
                PC.HiggsBosonComponent.bMHActive = false
                PC.HiggsBosonComponent:ControlMHActive(0)
            end
        end
    end)

    -- 6. Anti-cheat hooks
    pcall(function()
        local HiggsBosonComponent = require("GameLua.Mod.BaseMod.Common.Security.HiggsBosonComponent")
        if HiggsBosonComponent then
            if HiggsBosonComponent.StaticShowSecurityAlertInDev then
                HiggsBosonComponent.StaticShowSecurityAlertInDev = function() end
            end
            if HiggsBosonComponent.BlackList then
                for k in pairs(HiggsBosonComponent.BlackList) do
                    HiggsBosonComponent.BlackList[k] = nil
                end
            end
        end
        if _G.AvatarCheckCallback then
            _G.AvatarCheckCallback.StartAvatarCheck = function(obj) end
            _G.AvatarCheckCallback.OnReportItemID  = function(obj) end
        end
        _G.BlackList = {}
        _G.GlobalPlayerCoronaData = _G.GlobalPlayerCoronaData or {}
        _G.GlobalPlayerCheatTimes = _G.GlobalPlayerCheatTimes or {}
        local mt = getmetatable(_G.GlobalPlayerCoronaData) or {}
        mt.__newindex = function(t, k, v) end
        setmetatable(_G.GlobalPlayerCoronaData, mt)
        if _G.GameSafeCallbacks and _G.GameSafeCallbacks.RecordStrategyTimestampInReplay then
            _G.GameSafeCallbacks.RecordStrategyTimestampInReplay = function(...) end
            _G.GameSafeCallbacks.DoAttackFlowStrategy            = function() end
            _G.GameSafeCallbacks.GetScriptReportContent          = function() return "" end
        end
        local STExtraBlueprintFunctionLibrary = import("STExtraBlueprintFunctionLibrary")
        if STExtraBlueprintFunctionLibrary then
            STExtraBlueprintFunctionLibrary.IsDevelopment = function() return false end
        end
    end)

    -- 7. Anti-report
    pcall(function()
        local paths = {
            "GameLua.Mod.BaseMod.Client.Security.ClientReportPlayerSubsystem",
            "Client.Security.ClientReportPlayerSubsystem"
        }
        local ClientReportPlayerSubsystem = nil
        for _, path in ipairs(paths) do
            if package.loaded[path] then ClientReportPlayerSubsystem = package.loaded[path]; break end
            local ok, req = pcall(require, path)
            if ok and req then ClientReportPlayerSubsystem = req; break end
        end
        if ClientReportPlayerSubsystem then
            ClientReportPlayerSubsystem.OnInit                              = function(self) return end
            ClientReportPlayerSubsystem._OnPlayerKilledOtherPlayer          = function() return end
            ClientReportPlayerSubsystem._RecordFatalDamager                 = function() return end
            ClientReportPlayerSubsystem._OnDeathReplayDataWhenFatalDamaged  = function() return end
            ClientReportPlayerSubsystem._RecordMurdererFromDeathReplayData  = function() return end
            ClientReportPlayerSubsystem._RecordTeammatePlayerInfo           = function() return end
            ClientReportPlayerSubsystem._OnBattleResult                     = function() return end
            ClientReportPlayerSubsystem._OnShowQuickReportMutualExclusiveUI = function() return end
            ClientReportPlayerSubsystem.GetFatalDamagerMap                  = function() return {} end
            ClientReportPlayerSubsystem.GetCachedTeammateName2InfoMap       = function() return {} end
            ClientReportPlayerSubsystem.GetTeammateName2InfoMapDuringBattle = function() return {} end
            ClientReportPlayerSubsystem.GetCurrentNotInTeamHistoricalTeammateMap = function() return {} end
            ClientReportPlayerSubsystem.GetInTeamIndexFromHistoricalTeammateInfo = function() return -1 end
        end
        local ReportPlayerUtils = require("GameLua.Mod.BaseMod.Common.Security.ReportPlayerUtils")
        if ReportPlayerUtils then
            ReportPlayerUtils.RecordFatalDamager            = function() return end
            ReportPlayerUtils.IsUsingHistoricalTeammateInfo = function() return false end
            ReportPlayerUtils.IsCharacterDeliverAI          = function() return false end
        end
        local SecurityCommonUtils = require("GameLua.Mod.BaseMod.Common.Security.SecurityCommonUtils")
        if SecurityCommonUtils then
            SecurityCommonUtils.ExtractPlayerBasicInfo = function() return {} end
            SecurityCommonUtils.LogIf                 = function() return false end
        end
    end)

    -- 8. Gameplay flow reporting bypass
    pcall(function()
        if not _G.GameplayCallbacks then _G.GameplayCallbacks = {} end
        local GC = _G.GameplayCallbacks
        local origState = GC.OnDSPlayerStateChanged
        GC.OnDSPlayerStateChanged = function(UID, InPlayerState, bPureWatcher, bIsSafeExit, ParamReason)
            if InPlayerState and string.lower(tostring(InPlayerState)) == "cheatdetected" then return end
            if origState then return origState(UID, InPlayerState, bPureWatcher, bIsSafeExit, ParamReason) end
        end
        local function NoOpVoid() return end
        GC.ReportAttackFlow         = NoOpVoid; GC.ReportSecAttackFlow  = NoOpVoid
        GC.ReportHurtFlow           = NoOpVoid; GC.ReportFireArms       = NoOpVoid
        GC.ReportVerifyInfoFlow     = NoOpVoid; GC.ReportMrpcsFlow      = NoOpVoid
        GC.ReportPlayerBehavior     = NoOpVoid; GC.ReportTeammatHurt    = NoOpVoid
        GC.ReportMisKillByTeammate  = NoOpVoid; GC.ReportShootWeaponFlow= NoOpVoid
        GC.ReportUseVehicleFlow     = NoOpVoid; GC.ReportPickupItemFlow= NoOpVoid
        GC.ReportOpenBoxFlow        = NoOpVoid; GC.ReportKillPlayerFlow= NoOpVoid
        GC.ReportDieFlow            = NoOpVoid; GC.ReportRescueFlow    = NoOpVoid
        GC.ReportReviveFlow         = NoOpVoid; GC.ReportUseConsumableFlow = NoOpVoid
        GC.ReportThrowGrenadeFlow   = NoOpVoid; GC.ReportSwitchWeaponFlow  = NoOpVoid
        GC.ReportReloadFlow         = NoOpVoid; GC.ReportEnterVehicleFlow  = NoOpVoid
        GC.ReportExitVehicleFlow    = NoOpVoid; GC.ReportDamageVehicleFlow = NoOpVoid
        GC.ReportDestroyVehicleFlow = NoOpVoid
        GC.IsBypassed = true
    end)
end

pcall(_AK_InstallBypass)
print("[AK-Bypass] Sections 1-8 installed")

-- ================================================================
-- Globals
-- ================================================================
_G.A = _G.A or { Up = {} }
if not _G.A.Up then _G.A.Up = {} end
_G.LicenseValid = true
_G.ModsEnabled  = true
if not _G.IsLicenseOK then _G.IsLicenseOK = function() return true end end

-- ================================================================
-- SECTION 9: ESP BAN FIX (SAFE MODE)
-- ================================================================
do
local EspBanFix = {
    safeDistance = 10000,
    espEnabled = true,
    lastToggle = os.time(),
    toggleInterval = math.random(60, 180),
    blockCount = 0,
}

function EspBanFix:UpdateToggle()
    local elapsed = os.time() - self.lastToggle
    if elapsed >= self.toggleInterval then
        self.espEnabled = not self.espEnabled
        self.lastToggle = os.time()
        self.toggleInterval = math.random(60, 180)
    end
end

function EspBanFix:BlockDetection()
    pcall(function()
        local mgr = require("GameLua.GameCore.Module.Subsystem.SubsystemMgr")
        if mgr then
            local espSubs = {
                "ClientESPDetectionSubsystem","ClientAimTrackingSubsystem",
                "ClientRenderCheckSubsystem","ClientWallhackDetectionSubsystem",
                "ClientMemoryGuardSubsystem","ESPDetectionSubsystem",
                "RenderDetectionSubsystem","MarkDetectionSubsystem",
            }
            for _, name in ipairs(espSubs) do
                local sub = mgr:Get(name)
                if sub then
                    for k, v in pairs(sub) do
                        if type(v) == "function" and type(k) == "string" then
                            if k:find("Detect") or k:find("Check") or k:find("Report") or
                               k:find("Scan") or k:find("Verify") or k:find("Validate") then
                                sub[k] = function() return false end
                            end
                        end
                    end
                    self.blockCount = self.blockCount + 1
                end
            end
        end
    end)
    pcall(function()
        if _G.GameplayCallbacks then
            local GC = _G.GameplayCallbacks
            local espFuncs = {"ReportESP","ReportWallhack","ReportRenderAnomaly","CheckESP",
                              "CheckWallhack","CheckRender","OnESPDetected","OnWallhackDetected",
                              "OnRenderAnomaly","ValidateScreenMark","CheckScreenMark","ReportScreenMark"}
            for _, f in ipairs(espFuncs) do
                if GC[f] then GC[f] = function() return false end end
            end
        end
    end)
end

function EspBanFix:GetSafeMarkId() return 1006 end
function EspBanFix:Init() self:BlockDetection() end

_G.EspBanFix = EspBanFix
_G.EspBanFix:Init()

pcall(function()
    local tick2 = require("common.time_ticker")
    if tick2 then
        tick2.AddTimer(5, true, function()
            if _G.EspBanFix then _G.EspBanFix:UpdateToggle() end
        end)
    end
end)
end
-- END ESP BAN FIX

-- ================================================================
-- SECTION 10: BAN SHIELD 4.6 (SAFE MODE)
-- ================================================================
do
local function NoOp()    return true  end
local function NoFalse() return false end
local function NoZero()  return 0     end
local function NoNil()   return nil   end
local function NoList()  return {}    end
local function NoString()return ""    end

local function MuteObject(obj)
  if type(obj) ~= "table" then return end
  for k, v in pairs(obj) do
    if type(v) == "function" and type(k) == "string" and
      (k:find("Report") or k:find("Send") or k:find("Upload") or k:find("Verify") or
       k:find("Check") or k:find("Validate") or k:find("Scan") or k:find("Detect") or
       k:find("Collect") or k:find("Flow") or k:find("Heartbeat") or k:find("Record") or
       k:find("Trace") or k:find("Replay") or k:find("Save")) then
      pcall(function() obj[k] = NoOp end)
    end
  end
end

local BanShield = {}
local Shield = {}

function BanShield.KillBanFunctions()
  pcall(function()
    local banFuncs = {
      "BanPlayer","BanUser","ReportBan","SendBanReport","DetectBan","CheckBan",
      "ValidateBan","ProcessBan","BanKick","KickPlayer","ForceLogout","DisconnectPlayer",
      "ReportSuspicious","ReportCheat","ReportHack","OnCheatDetected","OnHackDetected",
      "OnViolationDetected","AntiCheatReport","CheatDetection","ViolationReport",
      "SecurityViolation","IntegrityCheck","SignatureVerify","TssSdkReport","TssSdkBan",
      "TssSdkKick","ReportModifierException","ReportMemoryException","ReportAvatarException",
      "ReportSpeedHack","ReportWallHack","ReportAimBot","ReportESP","ReportModdedFiles",
      "DetectCheat","OnBanNotice","OnKickNotice","ProcessBanNotice","HandleBanNotice",
      "ShowBanUI","ShowKickUI"
    }
    for _, fn in ipairs(banFuncs) do
      if _G[fn] then _G[fn] = function() return true end end
      if _G.GameplayCallbacks and _G.GameplayCallbacks[fn] then
        _G.GameplayCallbacks[fn] = function() return true end
      end
    end
  end)
end

function BanShield.SpoofSubsystems()
  pcall(function()
    local mgr = require("GameLua.GameCore.Module.Subsystem.SubsystemMgr")
    if not mgr then return end
    local banSubs = {
      "AntiCheatSubsystem","BanSubsystem","PlayerBanSubsystem","CheatDetectionSubsystem",
      "SecuritySubsystem","BanManagerSubsystem","KickBanSubsystem","TssSdkSubsystem",
      "HiggsBosonSubsystem","IntegrityCheckSubsystem","SignatureVerifySubsystem",
      "PlayerSecurityInfoSubsystem","OperationalStatsSubsystem","ModifierExceptionSubsystem",
      "MemoryCheckSubsystem"
    }
    for _, name in ipairs(banSubs) do
      local sub = mgr:Get(name)
      if sub then
        pcall(function()
          for k, v in pairs(sub) do
            if type(v) == "function" and type(k) == "string" then
              if k:find("Ban") or k:find("Kick") or k:find("Report") or k:find("Detect") or
                 k:find("Check") or k:find("Verify") or k:find("Validate") or k:find("Process") or
                 k:find("Send") or k:find("Upload") or k:find("Notify") or k:find("Warn") then
                sub[k] = function() return true end
              end
            end
          end
          sub.bBanned = false
          sub.bKicked = false
          sub.bSuspended = false
          sub.BanCount = 0
          sub.WarningCount = 0
          sub.SuspicionScore = 0
        end)
      end
    end
  end)
end

function BanShield.KillTssSdk()
  pcall(function()
    local tss = package.loaded["TssSdk"] or _G.TssSdk
    if tss then
      tss.GetFileMD5          = function() return "00000000000000000000000000000000" end
      tss.VerifyFileSignature = function() return true end
      tss.SendReportInfo      = function() return true end
      tss.ScanMemory          = function() return true end
      tss.IsEmulator          = function() return false end
      tss.GetTssSdkReportInfo = function() return "" end
      tss.CheckEnvironment    = function() return true end
      tss.VerifyProcess       = function() return true end
      tss.ReportBan           = function() return true end
      tss.ReportCheat         = function() return true end
      tss.BanPlayer           = function() return true end
      tss.KickPlayer          = function() return true end
    end
  end)
end

function BanShield.KillGameState()
  pcall(function()
    local GD = require("GameLua.GameCore.Data.GameplayData")
    if not GD then return end
    local gs = GD.GetGameState and GD.GetGameState()
    if not gs then return end
    pcall(function()
      gs.BanPlayer        = function() return true end
      gs.KickPlayer       = function() return true end
      gs.ReportCheat      = function() return true end
      gs.ReportHack       = function() return true end
      gs.OnCheatDetected  = function() return true end
      gs.OnHackDetected   = function() return true end
      gs.AntiCheatReport  = function() return true end
      gs.ShowBanNotice    = function() return end
      gs.ShowKickNotice   = function() return end
      gs.ProcessBanNotice = function() return end
    end)
  end)
end

function BanShield.SpoofBanStatus()
  pcall(function()
    local GD = require("GameLua.GameCore.Data.GameplayData")
    if not GD then return end
    local pc = GD.GetPlayerController and GD.GetPlayerController()
    if not pc then return end
    pcall(function()
      pc.bBanned = false; pc.bKicked = false; pc.bSuspended = false
      pc.BanReason = nil; pc.BanTime = 0; pc.BanCount = 0
      pc.WarningCount = 0; pc.SuspicionScore = 0
    end)
    pcall(function()
      local ps = pc.GetPlayerStateSafety and pc:GetPlayerStateSafety()
      if ps then
        ps.bBanned = false; ps.bKicked = false; ps.bSuspended = false
        ps.BanCount = 0; ps.WarningCount = 0; ps.SuspicionScore = 0
      end
    end)
  end)
end

function Shield.NeutralizeLoaders()
  pcall(function()
    if slua and slua.getSignature then slua.getSignature = NoZero end
    local loader = package.loaded["slua.loader"] or rawget(_G, "slua_loader")
    if loader then
      loader.verifyBytecode = NoOp
      loader.checkIntegrity = NoOp
    end
    if _G.slua_verify then _G.slua_verify = NoOp end
    if _G.check_slua_integrity then _G.check_slua_integrity = NoOp end
  end)
end

function Shield.NeutralizeHashes()
  pcall(function()
    local console = import("KismetSystemLibrary")
    if console then
      console.ExecuteConsoleCommand(nil, "pak.DisablePakSignatureCheck 1")
      console.ExecuteConsoleCommand(nil, "s.VerifyPak 0")
    end
    local CMode = import("CreativeModeBlueprintLibrary")
    if CMode then
      CMode.MD5HashByteArray     = NoString
      CMode.MD5HashFile          = NoString
      CMode.GetContentDiffData   = function() return true, "OK" end
      CMode.VerifyFileIntegrity  = NoOp
    end
    if _G.MD5Hash then _G.MD5Hash = NoString end
    if _G.CRC32   then _G.CRC32   = NoZero   end
    if _G.SHA1    then _G.SHA1    = NoString end
    local fhc = package.loaded["common.file_hash_checker"]
    if fhc then fhc.CheckFileMD5 = NoOp; fhc.VerifyAll = NoOp; fhc.GetHash = NoString end
    local stx = import("STExtraBlueprintFunctionLibrary")
    if stx then stx.CheckMD5 = NoOp; stx.GetMD5 = NoString; stx.VerifyFile = NoOp end
  end)
end

function Shield.NeutralizeLogs()
  pcall(function()
    local SMTD = import("ScreenshotMTDer")
    if SMTD then
      SMTD.MTDePicture = NoString; SMTD.ReMTDePicture = NoString
      SMTD.HasCaptured = NoOp; SMTD.TakeScreenshot = NoNil
    end
    local tl = package.loaded["TLog"] or _G.TLog
    if tl then
      tl.Info, tl.Warning, tl.Error, tl.Debug = NoOp, NoOp, NoOp, NoOp
      tl.Report, tl.Send, tl.Flush = NoOp, NoOp, NoOp
    end
    local cs = package.loaded["CrashSight"] or _G.CrashSight
    if cs then
      cs.ReportException, cs.SetCustomData, cs.Log = NoOp, NoOp, NoOp
      cs.SendCrash, cs.ReportUserException = NoOp, NoOp
    end
  end)
end

local KillSubSystems = {
  "AFKReportorSubsystem","ClientDataStatistcsSubsystem","AvatarExceptionSubsystem",
  "ShootVerifySubSystemClient","MemoryCheckSubsystem","SpeedCheckSubsystem",
  "WallCheckSubsystem","FileCheckSubsystem","BehaviorScoreSubsystem",
  "CoronaLabSubsystem","PlayerSecurityInfoSubsystem","ClientCircleFlowSubsystem",
  "ModifierExceptionSubsystem","SimulateCharacterSubsystem","ClientReportPlayerSubsystem",
  "DSReportPlayerSubsystem","ClientHawkEyePatrolSubsystem","DSHawkEyePatrolSubsystem",
  "GameReportSubsystem","ReplaySubsystem","SwiftHawkSubsystem","AntiCheatSubsystem",
  "IntegrityCheckSubsystem","SignatureVerifySubsystem","MD5CheckSubsystem",
  "PakVerifySubsystem","OperationalStatsSubsystem","MrpcsFlowSubsystem",
  "CircleFlowSubsystem","ClientESPDetectionSubsystem","ClientAimTrackingSubsystem",
  "ClientRenderCheckSubsystem","ClientMemoryGuardSubsystem","ClientKernelCheckSubsystem",
  "ClientWallhackDetectionSubsystem","ClientAntiCheatSubsystem","ClientSecMrpcsFlowSubsystem"
}

function Shield.NeutralizeSubSystems()
  pcall(function()
    local mgr = require("GameLua.GameCore.Module.Subsystem.SubsystemMgr")
    if mgr then
      for _, name in ipairs(KillSubSystems) do
        local sub = mgr:Get(name)
        if sub then
          MuteObject(sub)
          for _, tm in ipairs({"timer","heartbeatTimer","reportTimer"}) do
            if sub[tm] then pcall(function() sub:RemoveGameTimer(sub[tm]) end) end
          end
        end
      end
    end
    local flowRunner = package.loaded["GameLua.Mod.Library.GamePlay.Avatar.Exception.AvatarExceptionPlayerInst"]
    if flowRunner then
      flowRunner.CheckAvatarException, flowRunner.CheckAvatarExceptionOnce = NoOp, NoOp
      flowRunner.ReportAvatarException = NoNil
      flowRunner.CheckSlotMeshVisible, flowRunner.CheckPawnVisible = NoFalse, NoFalse
      flowRunner.CheckCanBugglyPostException = NoFalse
    end
  end)
end

function Shield.NeutralizeHiggs()
  pcall(function()
    local Higgs = require("GameLua.Mod.BaseMod.Common.Security.HiggsBosonComponent")
    if Higgs then
      local methods = {
        "ControlMHActive","Tick","OnTick","MHActiveLogic","TriggerAvatarCheck",
        "StartAvatarCheck","ReportItemID","ReceiveAnyDamage","OnWeaponHitRecord",
        "ShowSecurityAlert","ServerReportAvatar","ClientReportNetAvatar","SendHisarData",
        "ValidateSecurityData","StaticShowSecurityAlertInDev","DisableHiggsBoson",
        "CheckMHActive","ReportViolation","ProcessSecurityEvent","ValidatePlayer","CheckIntegrity"
      }
      for _, m in ipairs(methods) do if Higgs[m] then Higgs[m] = NoNil end end
      Higgs.GetNetAvatarItemIDs = NoList
      Higgs.GetCurWeaponSkinID = NoZero
      Higgs.IsMHActive = NoFalse
      Higgs.bMHActive = false
      Higgs.bCallPreReplication = false
      if Higgs.BlackList then
        for k in pairs(Higgs.BlackList) do Higgs.BlackList[k] = nil end
      end
    end
    _G.BlackList = {}
    if _G.AvatarCheckCallback then
      _G.AvatarCheckCallback.StartAvatarCheck = NoNil
      _G.AvatarCheckCallback.OnReportItemID = NoNil
    end
  end)
end

function BanShield.Install()
  BanShield.KillBanFunctions()
  BanShield.SpoofSubsystems()
  BanShield.KillTssSdk()
  BanShield.KillGameState()
  BanShield.SpoofBanStatus()
end

function Shield.InstallAll()
  pcall(function() BanShield.Install() end)
  Shield.NeutralizeLoaders()
  Shield.NeutralizeHashes()
  Shield.NeutralizeLogs()
  Shield.NeutralizeSubSystems()
  Shield.NeutralizeHiggs()
  pcall(function()
    local pc = slua_GameFrontendHUD and slua_GameFrontendHUD:GetPlayerController()
    if slua.isValid(pc) then
      if pc.HiggsBoson then pc.HiggsBoson.bMHActive = false end
      if pc.HiggsBosonComponent then pc.HiggsBosonComponent.bMHActive = false end
    end
  end)
end

_G.AK_BanShield_Install  = BanShield.Install
_G.AK_Shield_InstallAll  = Shield.InstallAll
pcall(function() Shield.InstallAll() end)
print("[BAN BYPASS 4.6] All ban systems neutralized (SAFE MODE)")
end
-- END BAN SHIELD 4.6

-- ================================================================
-- SECTION 11: COMPLETE BYPASS STEPS (SAFE MODE)
-- ================================================================
local function UB_nop()          return true  end
local function UB_retFalse()     return false end
local function UB_retZero()      return 0     end
local function UB_retEmpty()     return {}    end
local function UB_retTrue()      return true  end
local function UB_retEmptyString() return ""  end

local function _AK_InstallComplete()
    -- STEP 2: SLUA + MD5
    pcall(function()
        if slua and slua.getSignature then slua.getSignature = function() return 0xDEADBEEF end end
        local loader = package.loaded["slua.loader"] or rawget(_G, "slua_loader")
        if loader then
            loader.verifyBytecode = UB_retTrue
            loader.checkIntegrity = UB_retTrue
        end
        local CMode = import("CreativeModeBlueprintLibrary")
        if CMode then
            CMode.MD5HashByteArray   = function() return "00000000000000000000000000000000" end
            CMode.MD5HashFile        = function() return "00000000000000000000000000000000" end
            CMode.GetContentDiffData = function() return true, "BYPASSED" end
        end
        local FileHashChecker = package.loaded["common.file_hash_checker"]
        if FileHashChecker then
            FileHashChecker.CheckFileMD5 = UB_retTrue
            FileHashChecker.VerifyAll    = UB_retTrue
        end
        local STExtra = import("STExtraBlueprintFunctionLibrary")
        if STExtra then
            STExtra.CheckMD5  = UB_retTrue
            STExtra.VerifyFile = UB_retTrue
        end
    end)

    -- STEP 4: SCANNER + REPLAY
    pcall(function()
        local SubMgr = require("GameLua.GameCore.Module.Subsystem.SubsystemMgr")
        if SubMgr then
            local subs = {"AFKReportorSubsystem","ClientDataStatistcsSubsystem",
                          "AvatarExceptionSubsystem","ShootVerifySubSystemClient",
                          "MemoryCheckSubsystem","SpeedCheckSubsystem","WallCheckSubsystem",
                          "FileCheckSubsystem","BehaviorScoreSubsystem"}
            for _, name in ipairs(subs) do
                local sub = SubMgr:Get(name)
                if sub then
                    for k, v in pairs(sub) do
                        if type(v) == "function" and (k:find("Report") or k:find("Send") or
                           k:find("Upload") or k:find("Verify") or k:find("Check") or
                           k:find("Validate") or k:find("Scan") or k:find("Detect")) then
                            pcall(function() sub[k] = UB_nop end)
                        end
                    end
                    if sub.ReportPingDelayTimer then
                        pcall(function() sub:RemoveGameTimer(sub.ReportPingDelayTimer) end)
                        sub.ReportPingDelayTimer = nil
                    end
                    sub.DelayCount = 0
                end
            end
        end
        local AvaEx = package.loaded["GameLua.Mod.Library.GamePlay.Avatar.Exception.AvatarExceptionPlayerInst"]
        if AvaEx then
            AvaEx.CheckAvatarException        = UB_nop
            AvaEx.CheckAvatarExceptionOnce    = UB_nop
            AvaEx.ReportAvatarException       = UB_nop
            AvaEx.CheckSlotMeshVisible        = UB_retFalse
            AvaEx.CheckPawnVisible            = UB_retFalse
            AvaEx.CheckCanBugglyPostException = UB_retFalse
        end
    end)

    -- STEP 5: REPORT + SECURITY
    pcall(function()
        local flows = {"ReportAimFlow","ReportHitFlow","ReportAttackFlow","ReportSecAttackFlow",
                       "ReportFireArms","ReportVerifyInfoFlow","ReportMrpcsFlow",
                       "ReportPlayerBehavior","ReportTeammatHurt","ReportMisKillByTeammate",
                       "ReportForbitPick","ReportPlayerMoveRoute","ReportPlayerPosition",
                       "ReportVehicleMoveFlow","ReportSecTgameMovingFlow","ReportParachuteData",
                       "ReportEquipmentFlow","ReportCircleFlow","ReportSecMrpcsFlow"}
        for _, f in ipairs(flows) do
            if _G[f] then _G[f] = UB_nop end
            if _G.GameplayCallbacks and _G.GameplayCallbacks[f] then _G.GameplayCallbacks[f] = UB_nop end
        end
        for _, f in ipairs({"CheckReportSecAttackFlowWithAttackFlow","CheckReportSecAttackFlow"}) do
            if _G[f] then _G[f] = UB_retFalse end
            if _G.GameplayCallbacks and _G.GameplayCallbacks[f] then _G.GameplayCallbacks[f] = UB_retFalse end
        end
    end)

    -- STEP 6: SWIFT + MORE
    pcall(function()
        for _, f in ipairs({"SwiftHawk","ClientSwiftHawk","ClientSwiftHawkWithParams","SendSwiftHawkData"}) do
            if _G[f] then _G[f] = UB_nop end
            if _G.GameplayCallbacks and _G.GameplayCallbacks[f] then _G.GameplayCallbacks[f] = UB_nop end
        end
        local sub = package.loaded["GameLua.Mod.BaseMod.Client.Security.SwiftHawkSubsystem"]
        if sub then
            sub.ReportData = UB_nop
            sub.SendReport = UB_nop
            sub.CollectTelemetry = UB_nop
        end
        local mgr = require("GameLua.GameCore.Module.Subsystem.SubsystemMgr")
        if mgr then
            local corona = mgr:Get("CoronaLabSubsystem")
            if corona then
                corona.ReportData       = UB_nop
                corona.SendToServer     = UB_nop
                corona.CollectTelemetry = UB_nop
            end
        end
    end)

    -- STEP 7: SHOOT + HIGGS
    pcall(function()
        local sub = package.loaded["GameLua.Dev.Subsystem.ShootVerifySubSystemClient"]
        if sub then
            sub.OnShootVerifyFailed = UB_nop
            sub.SendVerifyData      = UB_nop
            sub.ReportBulletHit     = UB_nop
            sub.UploadHitInfo       = UB_nop
            sub.VerifyShot          = UB_retTrue
        end
        local Higgs = require("GameLua.Mod.BaseMod.Common.Security.HiggsBosonComponent")
        if Higgs then
            for _, m in ipairs({"ControlMHActive","Tick","OnTick","MHActiveLogic","TriggerAvatarCheck",
                                "StartAvatarCheck","ReportItemID","ReceiveAnyDamage","OnWeaponHitRecord",
                                "ShowSecurityAlert","ServerReportAvatar","ClientReportNetAvatar",
                                "SendHisarData","ValidateSecurityData","StaticShowSecurityAlertInDev",
                                "DisableHiggsBoson","CheckMHActive","ReportViolation",
                                "ProcessSecurityEvent","ValidatePlayer","CheckIntegrity"}) do
                if Higgs[m] then Higgs[m] = UB_nop end
            end
            Higgs.GetNetAvatarItemIDs = UB_retEmpty
            Higgs.GetCurWeaponSkinID = UB_retZero
            Higgs.IsMHActive         = UB_retFalse
            Higgs.bMHActive          = false
            Higgs.bCallPreReplication= false
            if Higgs.BlackList then
                for k in pairs(Higgs.BlackList) do Higgs.BlackList[k] = nil end
            end
        end
        _G.BlackList = {}
    end)

    -- STEP 8: FINAL
    pcall(function()
        for _, path in ipairs({
            "GameLua.Mod.BaseMod.Client.Security.ClientReportPlayerSubsystem",
            "Client.Security.ClientReportPlayerSubsystem",
            "GameLua.Mod.BaseMod.DS.Security.DSReportPlayerSubsystem"
        }) do
            local sub = package.loaded[path]
            if not sub then
                local s, r = pcall(require, path)
                if s and r then sub = r end
            end
            if sub then
                for k, v in pairs(sub) do
                    if type(v) == "function" and (k:find("Report") or k:find("Record") or
                       k:find("Send") or k:find("Upload") or k:find("Notify")) then
                        pcall(function() sub[k] = UB_nop end)
                    end
                end
            end
        end
    end)
end

_G.StartBypass_Complete = _AK_InstallComplete
pcall(_AK_InstallComplete)
print("[BYPASS] STEP 1-8 COMPLETE — SAFE MODE")

-- ================================================================
-- SECTION 12: REPORT BYPASS 4.6 (SAFE MODE — Lua Only)
-- ================================================================
local function _AK_InstallReport46()
    pcall(function()
        -- Hook report modules
        local reportModules = {
            "GameLua.Mod.BaseMod.Client.Report.LogicReportPlayer",
            "GameLua.Mod.BaseMod.Client.Report.ReportPlayerSubsystem",
            "GameLua.Mod.BaseMod.Client.Security.ClientReportPlayerSubsystem",
            "Client.Security.ClientReportPlayerSubsystem",
            "GameLua.Mod.BaseMod.DS.Security.DSReportPlayerSubsystem",
            "GameLua.Mod.BaseMod.Client.Report.ReportCheat",
            "GameLua.Mod.BaseMod.Client.Report.ReportSuspicious"
        }
        for _, path in ipairs(reportModules) do
            local mod = package.loaded[path]
            if not mod then
                local ok, loaded = pcall(require, path)
                if ok and loaded then mod = loaded end
            end
            if mod and type(mod) == "table" then
                for k, v in pairs(mod) do
                    if type(v) == "function" and type(k) == "string" then
                        if k:find("Report") or k:find("Send") or k:find("Submit") or k:find("Notify") then
                            pcall(function() mod[k] = function() return true end end)
                        end
                    end
                end
            end
        end

        -- Block Report UI
        local reportUI = {
            "GameLua.Mod.BaseMod.Client.Report.ReportPlayerUI",
            "GameLua.Mod.BaseMod.Client.UI.ReportPlayerUI",
            "GameLua.Mod.BaseMod.Client.UI.ReportUI"
        }
        for _, path in ipairs(reportUI) do
            local mod = package.loaded[path]
            if not mod then
                local ok, loaded = pcall(require, path)
                if ok and loaded then mod = loaded end
            end
            if mod and mod.__inner_impl then
                pcall(function()
                    mod.__inner_impl.OnConfirmReport = function() return end
                    mod.__inner_impl.OnClickReport   = function() return end
                    mod.__inner_impl.SubmitReport    = function() return end
                end)
            end
        end

        -- Block gameplay callbacks
        if not _G.GameplayCallbacks then _G.GameplayCallbacks = {} end
        local GC = _G.GameplayCallbacks
        local callbacks = {
            "ReportAttackFlow","ReportSecAttackFlow","ReportFireArms","ReportVerifyInfoFlow",
            "ReportMrpcsFlow","ReportPlayerBehavior","ReportTeammatHurt","ReportMisKillByTeammate",
            "ReportForbitPick","ReportPlayerMoveRoute","ReportPlayerPosition","ReportVehicleMoveFlow",
            "ReportSecTgameMovingFlow","ReportParachuteData","ReportEquipmentFlow","ReportAimFlow",
            "ReportHitFlow","ReportCircleFlow","ReportPlayersPing","ReportPlayerIP",
            "ReportPlayerFramePingRecord","ReportDSNetSaturation","ReportNetContinuousSaturate",
            "ReportDSNetRate","SendTssSdkAntiDataToLobby","SendClientStats",
            "SendServerAvgTickDelta","ClientSecMrpcsFlow","SwiftHawk","ClientSwiftHawk",
            "ClientSwiftHawkWithParams"
        }
        for _, f in ipairs(callbacks) do
            GC[f] = function() return true end
            if _G[f] then _G[f] = function() return true end end
        end

        -- Neutralize Higgs
        local Higgs = package.loaded["GameLua.Mod.BaseMod.Common.Security.HiggsBosonComponent"]
        if Higgs then
            for _, m in ipairs({"ControlMHActive","Tick","OnTick","MHActiveLogic","TriggerAvatarCheck",
                                "StartAvatarCheck","ReportItemID","ReceiveAnyDamage","OnWeaponHitRecord",
                                "ShowSecurityAlert","ServerReportAvatar","ClientReportNetAvatar",
                                "SendHisarData","ValidateSecurityData","StaticShowSecurityAlertInDev",
                                "DisableHiggsBoson","CheckMHActive","ReportViolation",
                                "ProcessSecurityEvent","ValidatePlayer","CheckIntegrity"}) do
                if Higgs[m] then Higgs[m] = function() return true end end
            end
            Higgs.GetNetAvatarItemIDs = function() return {} end
            Higgs.GetCurWeaponSkinID = function() return 0 end
            Higgs.IsMHActive         = function() return false end
            Higgs.bMHActive          = false
            Higgs.bCallPreReplication= false
            if Higgs.BlackList then
                for k in pairs(Higgs.BlackList) do Higgs.BlackList[k] = nil end
            end
        end
        _G.BlackList = {}

        -- Block TSS SDK
        local tss = package.loaded["TssSdk"] or _G.TssSdk
        if tss then
            tss.GetFileMD5          = function() return "00000000000000000000000000000000" end
            tss.VerifyFileSignature = function() return true end
            tss.SendReportInfo      = function() return true end
            tss.ScanMemory          = function() return true end
            tss.IsEmulator          = function() return false end
            tss.GetTssSdkReportInfo = function() return "" end
            tss.CheckEnvironment    = function() return true end
            tss.VerifyProcess       = function() return true end
            tss.ReportBan           = function() return true end
            tss.ReportCheat         = function() return true end
            tss.BanPlayer           = function() return true end
            tss.KickPlayer          = function() return true end
        end

        -- Spoof server state
        if _G.GameplayCallbacks then
            local GC2 = _G.GameplayCallbacks
            local origState = GC2.OnDSPlayerStateChanged
            GC2.OnDSPlayerStateChanged = function(UID, State, bPure, bSafe, Param)
                local s = State and string.lower(tostring(State)) or ""
                local DANGER = {
                    ["cheatdetected"]=1,["connectionlost"]=1,["connectiontimeout"]=1,
                    ["connectionexception"]=1,["netdrivererror"]=1,["banned"]=1,
                    ["kicked"]=1,["suspended"]=1,["violationdetected"]=1,
                    ["integrityfailure"]=1,["securityviolation"]=1,["reportdetected"]=1
                }
                if DANGER[s] then return end
                if origState then pcall(origState, UID, State, bPure, bSafe, Param) end
            end
        end

        -- Block ban popup
        _G.ShowBanNotice    = function() return end
        _G.ShowKickNotice   = function() return end
        _G.ProcessBanNotice = function() return end
        _G.HandleBanNotice  = function() return end

        local banUI = {"client.slua.umg.BanNoticeUI","client.slua.umg.KickNoticeUI",
                       "GameLua.Mod.BaseMod.Client.UI.BanUI"}
        for _, path in ipairs(banUI) do
            local mod = package.loaded[path]
            if mod and type(mod) == "table" then
                for k, v in pairs(mod) do
                    if type(v) == "function" and k:find("Show") then
                        pcall(function() mod[k] = function() return end end)
                    end
                end
            end
        end
    end)
end

_G.AK_Report46_Install = _AK_InstallReport46
pcall(_AK_InstallReport46)
print("[4.6] REPORT BYPASS SYSTEM ACTIVE — SAFE MODE")

-- ================================================================
-- SECTION 13: AUTO RE-BYPASS PER MATCH (NEW)
-- Deteksi transisi lobby→match dan re-install semua bypass
-- ================================================================
do
    local Rebypass = {
        inMatch = false,
        lastTick = 0,
        lastInstallTime = 0,
        installCount = 0,
        checkInterval = 2.0,
    }

    local function _isInMatch()
        local result = false
        pcall(function()
            local GD = require("GameLua.GameCore.Data.GameplayData")
            if GD and GD.GetPlayerCharacter then
                local ch = GD.GetPlayerCharacter()
                if ch and slua and slua.isValid and slua.isValid(ch) then
                    -- Pastikan benar-benar in-match (bukan lobby dummy)
                    -- Cek: punya TeamID valid / state fighting
                    local fighting = false
                    pcall(function()
                        local GS = require("client.common.game_status")
                        if GS and GS.IsInFightingStatus then
                            fighting = GS.IsInFightingStatus() == true
                        end
                    end)
                    if fighting then result = true end
                end
            end
        end)
        return result
    end

    local function _reInstallAll()
        local now = os.clock()
        -- Cooldown 5 detik antar install (mencegah spam)
        if now - Rebypass.lastInstallTime < 5.0 then return end
        Rebypass.lastInstallTime = now
        Rebypass.installCount = Rebypass.installCount + 1

        print(string.format("[AK-Rebypass] Re-installing... (match #%d)", Rebypass.installCount))

        -- Reset semua guard
        _G.A = _G.A or {}
        _G.A.Up = _G.A.Up or {}
        _G.A.Up.BanShielded = false
        _G.CompleteBypassStarted = false

        -- Re-run setiap module
        if _G.AK_InstallBypass       then pcall(_G.AK_InstallBypass) end
        if _G.AK_BanShield_Install   then pcall(_G.AK_BanShield_Install) end
        if _G.AK_Shield_InstallAll   then pcall(_G.AK_Shield_InstallAll) end
        if _G.StartBypass_Complete   then pcall(_G.StartBypass_Complete) end
        if _G.AK_Report46_Install    then pcall(_G.AK_Report46_Install) end

        -- Re-spoof Higgs Boson (subsystem baru tiap match)
        pcall(function()
            local pc = slua_GameFrontendHUD and slua_GameFrontendHUD:GetPlayerController()
            if pc and slua.isValid(pc) then
                if pc.HiggsBoson then
                    pc.HiggsBoson.bMHActive = false
                    pc.HiggsBoson.bCallPreReplication = false
                end
                if pc.HiggsBosonComponent then
                    pc.HiggsBosonComponent.bMHActive = false
                    pc.HiggsBosonComponent:ControlMHActive(0)
                end
            end
        end)

        -- Re-spoof GameReport subsystem (kalau baru dibuat)
        pcall(function()
            local mgr = require("GameLua.GameCore.Module.Subsystem.SubsystemMgr")
            if mgr then
                local grs = mgr:Get("GameReportSubsystem")
                if grs then
                    grs.ReplayReportData            = function() return false end
                    grs.CheckCanBugglyPostException = function() return false end
                    grs.BugglyPostExceptionFull     = function() return false end
                end
                local avEx = mgr:Get("AvatarExceptionSubsystem")
                if avEx then
                    avEx.ReportException     = function() end
                    avEx.CheckAvatarValid    = function() return true end
                end
                local sv = mgr:Get("ShootVerifySubSystemClient")
                if sv then
                    sv.ReportVerifyFail = function() end
                    sv.OnVerifyFailed   = function() end
                end
            end
        end)

        print("[AK-Rebypass] Re-install complete")
    end

    -- Loop monitoring
    pcall(function()
        local ticker = require("common.time_ticker")
        if not (ticker and ticker.AddTimerLoop) then return end

        ticker.AddTimerLoop(Rebypass.checkInterval, function()
            pcall(function()
                local now = _isInMatch()

                -- Transisi: lobby → match
                if now and not Rebypass.inMatch then
                    Rebypass.inMatch = true
                    print("[AK-Rebypass] Match detected — scheduling re-install")
                    -- Delay 3 detik agar subsystem game sudah selesai init
                    if ticker.AddTimerOnce then
                        ticker.AddTimerOnce(3.0, function()
                            pcall(_reInstallAll)
                        end)
                    else
                        pcall(_reInstallAll)
                    end
                end

                -- Transisi: match → lobby
                if not now and Rebypass.inMatch then
                    Rebypass.inMatch = false
                    print("[AK-Rebypass] Returned to lobby")
                end
            end)
        end, -1, Rebypass.checkInterval)
    end)

    _G.AK_Rebypass_Manual = _reInstallAll
    _G.AK_Rebypass_Status = function()
        return {
            inMatch = Rebypass.inMatch,
            installCount = Rebypass.installCount,
            lastInstall = Rebypass.lastInstallTime,
        }
    end

    print("[AK-Rebypass] Auto re-bypass ticker started (check every " ..
          Rebypass.checkInterval .. "s)")
end
-- END SECTION 13

-- ================================================================
-- GLOBAL EXPOSURE (untuk re-invoke dari luar)
-- ================================================================

_G.AK_Bypass_Install    = _AK_InstallBypass
_G.AK_InstallBypass     = _AK_InstallBypass
_G.AK_StartBypass       = _AK_InstallComplete
_G.AK_InstallReport46   = _AK_InstallReport46
_G.AK_Bypass_Ready      = true
_G.AK_ExtendedReady     = true

print("[AK-Bypass] ==================================")
print("[AK-Bypass] ALL SECTIONS 1-13 INSTALLED")
print("[AK-Bypass] SAFE MODE + AUTO RE-BYPASS ACTIVE")
print("[AK-Bypass] ==================================")
)Ultimate_LUA_END";