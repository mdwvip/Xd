const char* myBypassLuaScript2 = R"Ultimate_LUA_END(
-- ============================================================
-- SAFE BYPASS 1,2,4,5,6,7 - FIXED FORCE CLOSE
-- ============================================================

local function noop() end
local function retFalse() return false end
local function retTrue() return true end
local function retZero() return 0 end
local function retEmpty() return {} end
local function retEmptyString() return "" end

local function safeImport(name)
    local ok, mod = pcall(import, name)
    if ok and mod then return mod end
    return nil
end

local function getPC()
    local ok, pc = pcall(function()
        return slua_GameFrontendHUD and slua_GameFrontendHUD:GetPlayerController()
    end)
    if ok and pc and slua.isValid(pc) then return pc end
    return nil
end

-- helper untuk patch method pada module + inner_impl (safe)
local function patchTable(tbl, methods, retvals)
    if type(tbl) ~= "table" then return end
    if methods then
        for k, v in pairs(methods) do
            if type(tbl[k]) == "function" then tbl[k] = v end
        end
    end
    if retvals then
        for k, v in pairs(retvals) do
            if type(tbl[k]) == "function" then tbl[k] = v end
        end
    end
end

local function patchModule(path, methods, retvals)
    pcall(function()
        local t = package.loaded[path]
        if type(t) ~= "table" then return end
        patchTable(t, methods, retvals)
        if type(t.__inner_impl) == "table" then
            patchTable(t.__inner_impl, methods, retvals)
        end
    end)
end

-- ============================================================
-- SECTION 1: ANTI-CHEAT BYPASS
-- ============================================================

local function HiggsBosonBypass()
    pcall(function()
        local HB = package.loaded["GameLua.Mod.BaseMod.Common.Security.HiggsBosonComponent"]
        if type(HB) ~= "table" then return end
        local impl = HB.__inner_impl
        if type(impl) == "table" then
            impl.ControlMHActive = noop
            impl.Tick = noop
            impl.OnTick = noop
            impl.ReceiveTick = noop
            impl.MHActiveLogic = noop
            impl.TriggerAvatarCheck = noop
            impl.StartAvatarCheck = noop
            impl.ReportItemID = noop
            impl.OnReportItemID = noop
            impl.ReceiveAnyDamage = noop
            impl.OnWeaponHitRecord = noop
            impl.ShowSecurityAlert = noop
            impl.StaticShowSecurityAlertInDev = noop
            impl.SendHisarData = noop
            impl.SendAntiDataFlow = noop
            impl.SendHitFireBtnFlow = noop
            impl.OnBattleResult = noop
            impl.SkipAlertServer = noop
        end
        if type(HB.CheckWeaponIntegrity) == "function" then HB.CheckWeaponIntegrity = retTrue end
        if type(HB.CheckAvatarIntegrity) == "function" then HB.CheckAvatarIntegrity = retTrue end
        if type(HB.CheckBulletIntegrity) == "function" then HB.CheckBulletIntegrity = retTrue end
        if type(HB.GetNetAvatarItemIDs) == "function" then HB.GetNetAvatarItemIDs = retEmpty end
        if type(HB.GetCurWeaponSkinID) == "function" then HB.GetCurWeaponSkinID = retZero end
    end)
    -- PC-side: matikan MHActive
    pcall(function()
        local pc = getPC()
        if not pc then return end
        if pc.HiggsBoson then
            pc.HiggsBoson.bMHActive = false
            pc.HiggsBoson.bCallPreReplication = false
        end
        if pc.HiggsBosonComponent then
            pc.HiggsBosonComponent.bMHActive = false
            pc.HiggsBosonComponent.bCallPreReplication = false
        end
    end)
    print("[BYPASS] HiggsBoson Done")
end

local function SafetyDetectionBypass()
    patchModule("GameLua.Mod.BaseMod.Common.Security.SafetyDetectionSubsystem", {
        DetectAbnormal = noop,
        ReportAbnormal = noop,
        OnDetectionResult = noop,
        TriggerSafetyScan = noop,
    }, {
        GetScanResults = retEmpty,
        IsAnomalyDetected = retFalse,
    })
end

local function TssSdkBypass()
    pcall(function()
        local T = _G.TssSdk or package.loaded["TssSdk"]
        if type(T) ~= "table" then return end
        T.ReportData = noop
        T.SendToServer = noop
        T.SetUserInfo = noop
        T.SendReportInfo = noop
        T.OnRecvData = noop
        T.ScanMemory = retTrue
        T.IsEmulator = retFalse
        T.GetTssSdkReportInfo = retEmptyString
        T.ReportException = noop
        T.CheckIntegrity = retTrue
        T.VerifySignature = retTrue
    end)
    pcall(function()
        local T = _G.TssSDK
        if type(T) == "table" then
            T.ReportData = noop
            T.SendToServer = noop
            T.SetUserInfo = noop
            T.Init = noop
            T.Start = noop
            T.Verify = retTrue
            T.CheckIntegrity = retTrue
            T.Check = retTrue
            T.GetSignature = function() return "BYPASSED" end
        end
    end)
    pcall(function()
        local T = _G.TssSDKHelper
        if type(T) == "table" then T.ReportData = noop end
    end)
    print("[BYPASS] TSS SDK Done")
end

local function AceBypass()
    pcall(function()
        local ace = _G.ace or package.loaded["libace.so"]
        if type(ace) ~= "table" then return end
        ace.ReportData = noop
        ace.CheckIntegrity = retTrue
        ace.ScanMemory = retFalse
        ace.VerifyProcess = retTrue
        ace.CheckModule = retTrue
        ace.ReportViolation = noop
        ace.KickPlayer = noop
        ace.BanPlayer = noop
        ace.CollectInfo = retEmpty
        ace.SendReport = noop
        ace.ValidateClient = retTrue
    end)
end

local function XignCodeBypass()
    pcall(function()
        local X = _G.XignCode or package.loaded["xigncode"]
        if type(X) ~= "table" then return end
        X.SendReport = noop
        X.CheckProcess = retTrue
        X.VerifyIntegrity = retTrue
        X.ScanModules = retEmpty
        X.ReportException = noop
        X.ValidateMemory = retTrue
    end)
end

local function BattlEyeBypass()
    pcall(function()
        local B = _G.BattlEye or package.loaded["BattlEye"]
        if type(B) ~= "table" then return end
        B.SendReport = noop
        B.KickPlayer = noop
        B.ValidatePlayer = retTrue
        B.CheckMemory = retTrue
        B.VerifyIntegrity = retTrue
        B.ReportViolation = noop
    end)
end

local function JNIAntiCheatBypass()
    pcall(function()
        local J = _G.JNI and _G.JNI.AntiCheat
        if type(J) ~= "table" then return end
        J.CheckRoot = retFalse
        J.CheckEmulator = retFalse
        J.CheckDebugger = retFalse
        J.CollectInfo = retEmpty
        J.SendReport = noop
        J.Validate = retTrue
    end)
end

local function HawkEyeBypass()
    patchModule("GameLua.Mod.BaseMod.Client.Security.ClientHawkEyePatrolSubsystem", {
        _OnHawkSync = noop,
        _OnHawkReportSuccess = noop,
        _StartExitGameTimer = noop,
        _OnRecvInspectorBroadcastCount = noop,
        SendReportTLog = noop,
        ReportCheat = noop,
        _OnHawkFlag = noop,
        ReportPlayerFlag = noop,
        RequestFlagPlayer = noop,
        SendFlagReport = noop,
        RequestImprison = noop,
        _InitHawkEyePatrolSubsystem = noop,
        _CollectBeWatchedPlayerInfo = noop,
        ServerRPC_HawkReportCheat = noop,
    }, {
        IsDuringHawkEyePatrol = retFalse,
        HasReported = retTrue,
        CanInspectorBroadcast = retFalse,
    })
    patchModule("GameLua.Mod.BaseMod.Client.Security.HawkEyeSpectate.ClientHawkEyePatrolSubsystem", {
        _OnHawkSync = noop,
        _OnHawkReportSuccess = noop,
    })
    print("[BYPASS] HawkEye Done")
end

local function GokubaBypass()
    pcall(function()
        local G = package.loaded["GameLua.Mod.BaseMod.Client.Security.Gokuba"]
        if type(G) ~= "table" then return end
        G.ForwardFeature = function() return {0, 0, 0, 0, 0} end
        G.InitGokubaLogic = noop
    end)
end

local function CoronaLabBypass()
    pcall(function()
        local C = _G.CoronaLab
        if type(C) ~= "table" then return end
        C.ReportData = noop
        C.SendData = noop
        C.CollectData = noop
        C.Telemetry = noop
    end)
    patchModule("GameLua.Mod.BaseMod.Common.Security.CoronaUploader", {
        Upload = noop,
        Flush = noop,
    })
end

local function SwiftHawkBypass()
    pcall(function()
        local S = package.loaded["GameLua.Mod.BaseMod.Client.Security.SwiftHawkSubsystem"]
        if type(S) ~= "table" then return end
        S.ReportData = noop
        S.SendReport = noop
        S.CollectTelemetry = noop
        S.InitSubsystem = noop
        S.StartCollection = noop
        S.StopCollection = noop
    end)
    pcall(function()
        for _, name in ipairs({"SwiftHawk", "ClientSwiftHawk", "ClientSwiftHawkWithParams", "SendSwiftHawkData", "SwiftHawkReport"}) do
            if type(_G[name]) == "function" then _G[name] = noop end
        end
    end)
end

local function RacingAntiCheatBypass()
    patchModule("GameLua.Mod.SocialIsland.DS.Battle.RacingAntiCheatLogic", {
        StartDetectTimer = noop,
        StopDetectTimer = noop,
        DetectVehicleFloating = noop,
        HandleFloatingCheat = noop,
        HandleSpeedCheat = noop,
        HandlePlayerPassCheckBelt = noop,
    })
end

local function SecurityNotifyBypass()
    patchModule("GameLua.Mod.BaseMod.Common.Security.SecurityNotifyPCFeature", {
        ClientRPC_SyncBanID = noop,
        ClientRPC_StrongTips = noop,
        ClientRPC_NormalTips = noop,
        Notify = noop,
        ClientRPC_NotifyBan = noop,
        ClientRPC_NotifyPunish = noop,
        ClientRPC_NotifyIllegalProgram = noop,
    })
end

-- ============================================================
-- SECTION 2: REPORT & BAN BYPASS
-- ============================================================

local function ClientBanLogicBypass()
    patchModule("client.slua.logic.ban.ClientBanLogic", {
        OnSyncBanInfo = noop,
        OnVoiceBanNotify = noop,
        OnRealTimeVoiceBanNotify = noop,
        OnVoiceBanSuccess = noop,
        OnSyncMicSuspicious = noop,
        OnSyncMicPreFilter = noop,
        OnNotifyWarningTips = noop,
        ReqBanInfo = noop,
    }, {
        CheckBan = retFalse,
        IsBanned = retFalse,
        CheckBanStatus = retFalse,
        GetBanInfo = retEmpty,
    })
    pcall(function()
        local B = _G.ClientBanLogic
        if type(B) == "table" then
            B.OnSyncBanInfo = noop
            B.OnVoiceBanNotify = noop
            B.OnRealTimeVoiceBanNotify = noop
            B.OnNotifyWarningTips = noop
            B.ReqBanInfo = noop
            B.CheckBan = retFalse
            B.IsBanned = retFalse
        end
    end)
end

local function BanTipsLogicBypass()
    patchModule("client.slua.logic.ban.BanTipsLogic", {
        ShowBanTips = noop,
        ShowPunishTips = noop,
        ShowWarningTips = noop,
        OnReceiveBanNotice = noop,
    })
end

local function RealTimeBanBypass()
    patchModule("GameLua.Mod.BaseMod.Common.RealTimeBan.RealTimeBan", {
        OnPlayerWithRealTimeBan = noop,
        ShowAlias = noop,
        HandleEnterGameModeFightingState = noop,
    }, {
        GetTipsID = retZero,
        IsBanned = retFalse,
        GetBanTime = retZero,
        GetBanReason = retEmptyString,
    })
end

local function ClientReportPlayerBypass()
    patchModule("GameLua.Mod.BaseMod.Client.Security.ClientReportPlayerSubsystem", {
        OnInit = noop,
        _OnPlayerKilledOtherPlayer = noop,
        _RecordFatalDamager = noop,
        _OnDeathReplayDataWhenFatalDamaged = noop,
        _RecordMurdererFromDeathReplayData = noop,
        _RecordTeammatePlayerInfo = noop,
        _OnBattleResult = noop,
        _OnShowQuickReportMutualExclusiveUI = noop,
        ReportSuspiciousPlayer = noop,
        SubmitReport = noop,
        ProcessReport = noop,
        ClientRPC_SyncFatalDamagerMap = noop,
    }, {
        GetFatalDamagerMap = retEmpty,
        GetCachedTeammateName2InfoMap = retEmpty,
        GetTeammateName2InfoMapDuringBattle = retEmpty,
        GetCurrentNotInTeamHistoricalTeammateMap = retEmpty,
    })
end

local function DSReportPlayerBypass()
    patchModule("GameLua.Mod.BaseMod.Common.Security.DSReportPlayerSubsystem", {
        OnInit = noop,
        _OnNearDeathOrRescued = noop,
        _OnCharacterDied = noop,
        _OnTeammateDamage = noop,
        _OnPlayerSettlementStart = noop,
        _AddKnockDownerToBattleResult = noop,
        _AddKillerToBattleResult = noop,
        _AddTeammateMurderToBattleResult = noop,
        _AddFatalDamagerMapToBattleResult = noop,
        _AddMLKillerUIDToBattleResult = noop,
        _SaveHistoricalTeammateInfo = noop,
        _RecordFatalDamager = noop,
        _RecordTeammateMurderer = noop,
        _AddEnemyMapToBattleResult = noop,
        _AddTeammateMapToBattleResult = noop,
        _SubmitAbnormalData = noop,
    })
end

local function QuickReportBypass()
    patchModule("GameLua.Mod.BaseMod.Client.Security.ClientQuickReportMaliciousTeammate", {
        OnShowMutualExclusiveUI = noop,
        OnHideMutualExclusiveUI = noop,
        MaliciousTeammateReceiveWarningTips = noop,
        MaliciousTeammateVictimReceiveTips = noop,
    })
end

local function InspectionReportBypass()
    patchModule("GameLua.Mod.BaseMod.Client.Security.InspectionSystemReportClientLogicSubsystem", {
        AskForInspector = noop,
        ReportEnemy = noop,
        KickOutOneTeam = noop,
        OnReceiveInspectCmd = noop,
        ClientReportData = noop,
        SendReportToInspector = noop,
        SendKickOutOneTeam = noop,
        ClientNotifyInspectorImplementation = noop,
        RecvNotifyInspector = noop,
    })
    patchModule("GameLua.Mod.BaseMod.DS.Security.InspectionSystemReportDSLogicSubsystem", {
        ServerKickOutOneTeamByPlayerImplementation = noop,
        AddReportedCount = noop,
        AddInspectionRecord = noop,
        BanPlayerByInspection = noop,
        BroadCastToAllInspector = noop,
        ServerReportToInspectorImplementation = noop,
        InitPlayerInspectionInfo = noop,
    })
end

local function ReportCooldownBypass()
    patchModule("client.slua.logic.report.ReportCooldownLogic", {
        ResetCooldown = noop,
        OnReportCooldownEnd = noop,
    }, {
        CheckCanReport = retFalse,
        GetCooldownTime = retZero,
    })
end

local function PlayerReportBypass()
    patchModule("client.slua.logic.report.PlayerReportLogic", {
        SendReport = noop,
        ReportCheat = noop,
        ReportAbuse = noop,
        ReportAFK = noop,
        ReportTeammate = noop,
        OnReportResponse = noop,
    })
end

local function AFKReportBypass()
    patchModule("GameLua.Mod.BaseMod.DS.Security.AFKReportorSubsystem", {
        HandleEnterFighting = noop,
        InitializePlayerInputInfo = noop,
        AddOneAFKInfo = noop,
        SetPlayerAFKState = noop,
        ResetPlayerInputInfo = noop,
        PlayerHaveAction = noop,
        ReportAFK = noop,
    }, {
        CheckAFK = retFalse,
    })
end

local function BehaviorScoreBypass()
    patchModule("GameLua.Mod.Escape.Gameplay.Subsystem.BehaviorScoreSubsystem", {
        OnHandleBehaviorScore = noop,
        AIPerceptionScore = noop,
        ReportBehavior = noop,
    }, {
        CalcFinalScore = retZero,
    })
end

local function FlagSubsystemBypass()
    patchModule("GameLua.Mod.BaseMod.Client.Security.ClientFlagSubsystem", {
        EvaluateFlags = noop,
        ReportFlag = noop,
        SyncFlagStatus = noop,
        IncreaseFlagCount = noop,
        ResetFlags = noop,
    }, {
        GetFlagLevel = retZero,
        GetFlagBanDuration = retZero,
        IsFlagged = retFalse,
    })
    patchModule("client.slua.logic.ban.logic_flag_ban", {
        GetFlagBanEndTime = function() return 0 end,
        IsFlagBanned = retFalse,
        GetFlagBanDuration = retZero,
        CheckFlagBan = retFalse,
    })
end

local function LoginBanBypass()
    patchModule("client.slua.logic.login.logic_login_ban", {
        GetBanInfo = function() return { end_time = 0 } end,
    }, {
        CheckCanLogin = retTrue,
        IsBanned = retFalse,
        IsSecurityBan = retFalse,
    })
    patchModule("client.slua.logic.ban.logic_ban", {
        GetBanEndTime = function() return 0 end,
    }, {
        IsInBanTime = retFalse,
        CheckBanStatus = retFalse,
        GetBanReason = retEmpty,
        GetBanTime = retZero,
    })
    patchModule("client.slua.logic.login.logic_tt_ban", {
        CheckIfCanCreateRole = noop,
        JumpAppealURL = retFalse,
        GetCarrierInfo = function() return '[{"mcc":"000"}]' end,
    })
end

-- ============================================================
-- SECTION 4: INTEGRITY & SIGNATURE
-- ============================================================

local function MD5Bypass()
    pcall(function()
        local pc = getPC()
        if not pc then return end
        local KSL = safeImport("KismetSystemLibrary")
        if not KSL or not KSL.ExecuteConsoleCommand then return end
        pcall(KSL.ExecuteConsoleCommand, pc, "pak.DisablePakSignatureCheck 1")
        pcall(KSL.ExecuteConsoleCommand, pc, "s.VerifyPak 0")
        pcall(KSL.ExecuteConsoleCommand, pc, "sig.Check 0")
    end)
    pcall(function()
        local CMode = safeImport("CreativeModeBlueprintLibrary")
        if not CMode then return end
        pcall(function() CMode.MD5HashByteArray = function() return "00000000000000000000000000000000" end end)
        pcall(function() CMode.MD5HashFile = function() return "00000000000000000000000000000000" end end)
        pcall(function() CMode.GetContentDiffData = function() return true, "BYPASSED" end end)
        pcall(function() CMode.VerifyFileIntegrity = retTrue end)
    end)
    pcall(function()
        if type(_G.STExtraBlueprintFunctionLibrary) == "table" then
            _G.STExtraBlueprintFunctionLibrary.CheckMD5 = retTrue
            _G.STExtraBlueprintFunctionLibrary.VerifyFile = retTrue
            _G.STExtraBlueprintFunctionLibrary.VerifySignature = retTrue
            _G.STExtraBlueprintFunctionLibrary.CheckIntegrity = retTrue
        end
    end)
    print("[BYPASS] MD5 Done")
end

local function applyFullCRCFaker()
    if _G.__CRCFakerDone then return end
    _G.__CRCFakerDone = true
    patchModule("client.slua.logic.pak.logic_pak_verify", nil, {
        Verify = retFalse,
        CheckPakFile = retZero,
        GetPakStatus = retZero,
    })
    patchModule("GameLua.Mod.BaseMod.Common.Security.PakIntegrityChecker", {
        ShowPakMismatchAlert = noop,
    }, {
        Verify = retFalse,
        CheckPakFile = retZero,
        GetPakStatus = retZero,
    })
    patchModule("GameLua.Mod.BaseMod.Common.Security.LibCheck", {
        Scan = noop,
        Report = noop,
    }, {
        Verify = retTrue,
        Check = retTrue,
        IsLibValid = retTrue,
        GetTamperedLibs = retEmpty,
    })
    pcall(function()
        if Client and type(Client) == "table" then
            Client.VerifyPakFile = retTrue
            Client.CheckFileCRC = retZero
            Client.VerifySignature = retTrue
            Client.CheckGameLuaIntegrity = retTrue
        end
    end)
    print("[BYPASS] CRC Faker Done")
end

local function SLUABypass()
    pcall(function()
        local loader = package.loaded["slua.loader"]
        if type(loader) == "table" then
            loader.verifyBytecode = retTrue
            loader.checkIntegrity = retTrue
        end
    end)
end

local function IntegrityPatches()
    patchModule("GameLua.Mod.BaseMod.Common.Security.LuaIntegrityCheck", {
        Run = noop,
    }, {
        Verify = retTrue,
        Check = retTrue,
    })
    patchModule("GameLua.Mod.BaseMod.Common.Security.APKIntegrity", nil, {
        CheckSignature = retTrue,
        CheckInstallSource = retTrue,
    })
    patchModule("GameLua.Mod.BaseMod.Common.Security.SecureBootCheck", nil, {
        VerifyBoot = retTrue,
    })
    patchModule("GameLua.Mod.BaseMod.Common.Security.IntegrityCheck", {
        Run = noop,
    }, {
        Verify = retTrue,
    })
    patchModule("GameLua.Mod.BaseMod.Common.Security.AntiDebug", {
        Report = noop,
    }, {
        Check = retFalse,
    })
    print("[BYPASS] Integrity Done")
end

-- ============================================================
-- SECTION 5: DEVICE / EMULATOR / ROOT / MEMORY
-- ============================================================

local function BlockGameGuardian()
    pcall(function()
        local GG = package.loaded["GameGuardianDetect"] or _G.GameGuardianDetect
        if type(GG) == "table" then
            GG.IsGGRunning = retFalse
            GG.CheckPackages = retEmpty
            GG.DetectGameGuardian = retFalse
            GG.ReportGameGuardian = noop
            GG.ValidateGG = retTrue
        end
    end)
end

local function BlockCheatEngine()
    pcall(function()
        local CE = package.loaded["CheatEngineDetect"] or _G.CheatEngineDetect
        if type(CE) == "table" then
            CE.IsCheatEngineRunning = retFalse
            CE.CheckProcessList = retEmpty
            CE.DetectCheatEngine = retFalse
            CE.ReportCheatEngine = noop
            CE.ValidateCE = retTrue
        end
    end)
end

local function BlockRootJailbreak()
    pcall(function()
        local R = package.loaded["RootDetect"] or _G.RootDetect
        if type(R) == "table" then
            R.CheckRoot = retFalse
            R.CheckSu = retFalse
            R.CheckMagisk = retFalse
            R.CheckSuperSU = retFalse
            R.DetectRoot = retFalse
            R.ReportRoot = noop
            R.ValidateRoot = retTrue
        end
    end)
    pcall(function()
        local J = package.loaded["JailbreakDetect"] or _G.JailbreakDetect
        if type(J) == "table" then
            J.CheckJailbreak = retFalse
            J.CheckCydia = retFalse
            J.DetectJailbreak = retFalse
            J.ReportJailbreak = noop
            J.ValidateJailbreak = retTrue
        end
    end)
end

local function BlockEmulatorDetection()
    pcall(function()
        local E = safeImport("EmulatorDetect")
        if type(E) == "table" then
            E.IsEmulator = retFalse
            E.GetEmulatorType = retEmptyString
            E.CheckVM = retFalse
            E.DetectEmulator = retFalse
            E.ReportEmulator = noop
            E.ValidateEmulator = retTrue
        end
    end)
    pcall(function()
        local ES = package.loaded["EmulatorSystem"]
        if type(ES) == "table" then
            ES.IsEmulator = retFalse
            ES.GetEmulatorName = function() return "NoEmulator" end
        end
    end)
    pcall(function()
        local LE = package.loaded["logic_emulator"]
        if type(LE) == "table" then
            LE.find_emulator = retFalse
            LE.IsSpecialEmulator = retFalse
        end
    end)
    print("[BYPASS] Emulator Done")
end

local function BlockTamperDetection()
    pcall(function()
        local FI = safeImport("FileIntegrity")
        if type(FI) == "table" then
            FI.VerifyFile = retTrue
            FI.CheckIntegrity = retTrue
            FI.ReportTamper = noop
            FI.ValidateFile = retTrue
            FI.IsFileValid = retTrue
        end
    end)
    pcall(function()
        local MT = safeImport("MemoryTamper")
        if type(MT) == "table" then
            MT.DetectTamper = retFalse
            MT.ReportTamper = noop
            MT.CheckTamper = retFalse
            MT.ValidateMemory = retTrue
        end
    end)
end

local function BlockAntiDebugging()
    pcall(function()
        local D = package.loaded["DebuggerDetect"] or _G.DebuggerDetect
        if type(D) == "table" then
            D.IsDebuggerPresent = retFalse
            D.CheckBreakpoint = retFalse
            D.CheckTracer = retFalse
            D.DetectDebugger = retFalse
        end
    end)
end

-- TIDAK menyentuh debug.* (getinfo/sethook/getlocal dsb)
local function MemoryProtectionBypass()
    pcall(function()
        local MP = safeImport("MemoryProtect")
        if type(MP) == "table" then
            MP.CheckMemory = retTrue
            MP.ValidateMemory = retTrue
            MP.VerifyMemory = retTrue
        end
    end)
    pcall(function()
        local MS = safeImport("MemoryScanner")
        if type(MS) == "table" then
            MS.ScanMemory = retFalse
            MS.ReportMemory = noop
            MS.IsMemoryValid = retTrue
        end
    end)
end

local function DNSDeviceBypass()
    pcall(function()
        local D = safeImport("DeviceID")
        if type(D) == "table" then
            D.GetDeviceID = function() return "BYPASSED_DEVICE" end
            D.GetAndroidID = function() return "BYPASSED_ANDROID_ID" end
            D.GetIMEI = function() return "BYPASSED_IMEI" end
            D.GetMACAddress = function() return "BYPASSED_MAC" end
        end
    end)
    pcall(function()
        local S = safeImport("SystemInfo")
        if type(S) == "table" then
            S.IsEmulator = retFalse
            S.IsRooted = retFalse
            S.IsDebugged = retFalse
        end
    end)
    patchModule("GameLua.Mod.BaseMod.Client.Security.DeviceFingerprint", {
        Collect = noop,
        Sync = noop,
    }, {
        GetHash = function() return "unknown" end,
    })
    patchModule("GameLua.Mod.BaseMod.DS.Security.DSDeviceCheck", {
        ReportMismatch = noop,
    }, {
        VerifyClientDevice = retTrue,
    })
    print("[BYPASS] Device Done")
end

local function TimingCheckSpoof()
    pcall(function()
        local GT = package.loaded["GameLua.GameCore.Data.GameTime"]
        if type(GT) == "table" then
            GT.GetDeltaTime = function() return 0.033 end
            GT.GetFrameTime = function() return 0.016 end
        end
    end)
end

-- ============================================================
-- SECTION 6: SHOOTING / MAGIC BULLET / ESP / NO RECOIL
-- ============================================================

local function MagicBulletBypass()
    pcall(function()
        local DV = safeImport("DamageVerification")
        if type(DV) == "table" then
            DV.VerifyDamage = retTrue
            DV.ReportAbnormalDamage = noop
            DV.IsDamageValid = retTrue
        end
    end)
    pcall(function()
        local HV = safeImport("HitboxVerification")
        if type(HV) == "table" then
            HV.VerifyHitbox = retTrue
            HV.ReportInvalidHit = noop
            HV.IsHitboxValid = retTrue
        end
    end)
    pcall(function()
        local PV = safeImport("ProjectileVerification")
        if type(PV) == "table" then
            PV.VerifyProjectile = retTrue
            PV.ReportAbnormalProjectile = noop
            PV.IsProjectileValid = retTrue
        end
    end)
    pcall(function()
        local BV = safeImport("BulletVerification")
        if type(BV) == "table" then
            BV.VerifyBullet = retTrue
            BV.ReportAbnormalBullet = noop
            BV.IsBulletValid = retTrue
        end
    end)
    patchModule("GameLua.Dev.Subsystem.ShootVerifySubSystemClient", {
        OnShootVerifyFailed = noop,
        SendVerifyData = noop,
    }, {
        VerifyShot = retTrue,
        IsShootValid = retTrue,
    })
    print("[BYPASS] Magic Bullet Done")
end

local function BlockESPDetection()
    pcall(function()
        local E = safeImport("ESPDetect")
        if type(E) == "table" then
            E.DetectESP = retFalse
            E.ReportESP = noop
            E.IsESPDetected = retFalse
        end
    end)
    pcall(function()
        local W = safeImport("WallhackDetect")
        if type(W) == "table" then
            W.DetectWallhack = retFalse
            W.ReportWallhack = noop
            W.IsWallhackDetected = retFalse
        end
    end)
end

local function BlockNoRecoilDetection()
    pcall(function()
        local NR = safeImport("NoRecoilDetect")
        if type(NR) == "table" then
            NR.DetectNoRecoil = retFalse
            NR.ReportNoRecoil = noop
            NR.IsNoRecoil = retFalse
        end
    end)
end

local function BlockSpeedHackDetection()
    pcall(function()
        local SH = safeImport("SpeedHackDetect")
        if type(SH) == "table" then
            SH.DetectSpeedHack = retFalse
            SH.ReportSpeedHack = noop
            SH.IsSpeedHack = retFalse
        end
    end)
    pcall(function()
        local TS = safeImport("TimeScale")
        if type(TS) == "table" then
            TS.CheckTimeScale = retTrue
            TS.IsTimeScaleValid = retTrue
        end
    end)
end

-- ============================================================
-- SECTION 7: SKIN / AVATAR / WEAPON / VEHICLE
-- ============================================================

local function SkinModBypass()
    pcall(function()
        local AU = safeImport("AvatarUtils")
        if type(AU) == "table" then
            AU.CheckIsWeaponInBlackList = retFalse
            AU.IsValidAvatar = retTrue
            AU.CheckAvatarIntegrity = retTrue
        end
    end)
    pcall(function()
        local WV = safeImport("WeaponVerification")
        if type(WV) == "table" then
            WV.VerifyWeapon = retTrue
            WV.IsWeaponValid = retTrue
        end
    end)
    pcall(function()
        local VV = safeImport("VehicleVerification")
        if type(VV) == "table" then
            VV.VerifyVehicle = retTrue
            VV.IsVehicleValid = retTrue
        end
    end)
    print("[BYPASS] Skin Done")
end

local function AvatarComponentBypass()
    pcall(function()
        local ok, CAC = pcall(require, "GameLua.Mod.Library.GamePlay.Avatar.Component.CharacterAvatarComponent")
        if not ok or not CAC or type(CAC) ~= "table" then return end
        if not CAC._bypass_valid_hooked then
            CAC._bypass_valid_hooked = true
            local orig = CAC.CheckItemValid
            CAC.CheckItemValid = function(self, resID)
                if type(resID) == "number" and resID > 1000000000 then return true end
                return orig and orig(self, resID) or true
            end
        end
    end)
end

local function BackpackBypass()
    if _G.DEV_WARDROBE_BP_HOOKED then return end
    _G.DEV_WARDROBE_BP_HOOKED = true
    pcall(function()
        local BU = safeImport("BackpackUtils")
        if type(BU) == "table" and BU.GetBPIDByResID then
            local orig = BU.GetBPIDByResID
            BU.GetBPIDByResID = function(resID)
                resID = tonumber(resID)
                if resID and resID > 1000000000 then
                    local bp = orig(resID)
                    if bp and bp > 0 then return bp end
                    return resID
                end
                return orig(resID)
            end
        end
    end)
    print("[BYPASS] Backpack Done")
end

-- ============================================================
-- WELCOME POPUP
-- ============================================================

local function TryShowWelcome()
    pcall(function()
        local ok, CommonMsgBoxMgr = pcall(require, "client.slua.logic.common.logic_common_msg_box")
        if not ok or not CommonMsgBoxMgr then return end
        local activeStatus = "WELCOME TO MT MOD\nSAFE BYPASS2"
        CommonMsgBoxMgr.Show(1, "MT MOD 4.6.0 64 BIT", activeStatus, function() end)
        _G.WelcomeShown = true
    end)
end

-- ============================================================
-- FORCE CLOSE (manual only)
-- ============================================================

local function ForceClose(reason)
    reason = tostring(reason or "ForceClose requested")
    print("[FORCECLOSE] " .. reason)
    pcall(function()
        local pc = getPC()
        if not pc then return end
        local KSL = safeImport("KismetSystemLibrary")
        if KSL and KSL.ExecuteConsoleCommand then
            pcall(KSL.ExecuteConsoleCommand, pc, "quit")
        end
    end)
    pcall(function() if os and os.exit then os.exit(0) end end)
end
_G.ForceClose = ForceClose

-- ============================================================
-- BOOTSTRAP
-- ============================================================

-- ============================================================
-- [LOGGER] Bypass Result Logger → /sdcard/Download/resultsallbypass2.json
-- ============================================================
_G.BypassResults2 = {
    meta = {
        mod = "AntiCheat",
        version = "V11",
        file = "AntiCheat.cpp",
        start_time = os.time(),
        start_time_str = os.date("%Y-%m-%d %H:%M:%S"),
    },
    bypasses = {},
    features = {},
    summary = {},
}

local function BypassLog(name, success, err_msg)
    _G.BypassResults2.bypasses[name] = {
        name = name,
        status = success and "OK" or "FAILED",
        timestamp = os.time(),
        time_str = os.date("%H:%M:%S"),
        error = err_msg or nil,
    }
    print(string.format("[BypassLog] %-45s => %s%s",
        name, success and "OK" or "FAILED",
        err_msg and (" [" .. tostring(err_msg) .. "]") or ""))
end

local function RunBypassSafe(name, fn)
    if type(fn) ~= "function" then
        BypassLog(name, false, "function not found")
        return false
    end
    local ok, err = pcall(fn)
    BypassLog(name, ok, not ok and tostring(err) or nil)
    return ok
end

local function json_escape(s)
    if not s then return "" end
    s = tostring(s)
    s = s:gsub("\\", "\\\\"):gsub('"', '\\"'):gsub("\n", "\\n"):gsub("\r", "\\r"):gsub("\t", "\\t")
    return s
end

local function table_to_json(t, indent)
    indent = indent or ""
    local nextIndent = indent .. "  "
    local ty = type(t)
    if ty == "nil" then return "null" end
    if ty == "boolean" or ty == "number" then return tostring(t) end
    if ty == "string" then return '"' .. json_escape(t) .. '"' end
    if ty ~= "table" then return '"' .. json_escape(tostring(t)) .. '"' end

    local is_array, count = true, 0
    for k, _ in pairs(t) do
        count = count + 1
        if type(k) ~= "number" then is_array = false; break end
    end
    if count == 0 then return "[]" end

    local parts = {}
    if is_array then
        for _, v in ipairs(t) do table.insert(parts, nextIndent .. table_to_json(v, nextIndent)) end
        return "[\n" .. table.concat(parts, ",\n") .. "\n" .. indent .. "]"
    else
        for k, v in pairs(t) do
            table.insert(parts, nextIndent .. '"' .. json_escape(tostring(k)) .. '": ' .. table_to_json(v, nextIndent))
        end
        return "{\n" .. table.concat(parts, ",\n") .. "\n" .. indent .. "}"
    end
end

function _G.SaveBypassResults2(extra_info)
    local total, ok_count, fail_count = 0, 0, 0
    for _, v in pairs(_G.BypassResults2.bypasses) do
        total = total + 1
        if v.status == "OK" then ok_count = ok_count + 1 else fail_count = fail_count + 1 end
    end
    _G.BypassResults2.summary = {
        total = total,
        success = ok_count,
        failed = fail_count,
        success_rate = total > 0 and string.format("%.1f%%", (ok_count / total) * 100) or "N/A",
    }
    _G.BypassResults2.meta.end_time = os.time()
    _G.BypassResults2.meta.end_time_str = os.date("%Y-%m-%d %H:%M:%S")
    _G.BypassResults2.meta.uptime_sec = _G.BypassResults2.meta.end_time - _G.BypassResults2.meta.start_time

    if extra_info then
        for k, v in pairs(extra_info) do _G.BypassResults2.meta[k] = v end
    end

    local json = table_to_json(_G.BypassResults2, "")
    local paths = {
        "/sdcard/Download/resultsallbypass2.json",
        "/storage/emulated/0/Download/resultsallbypass2.json",
        "/storage/emulated/0/Android/data/com.pubg.krmobile/files/resultsallbypass2.json",
    }

    local saved = false
    for _, path in ipairs(paths) do
        local ok, err = pcall(function()
            local f = io.open(path, "w")
            if not f then error("Cannot open " .. path) end
            f:write(json)
            f:close()
        end)
        if ok then
            print("[SaveBypassResults2] ✓ Saved → " .. path)
            saved = true
        else
            print("[SaveBypassResults2] ✗ Failed → " .. path .. " : " .. tostring(err))
        end
    end
    if not saved then
        print("[SaveBypassResults2] ⚠️ Semua path gagal! Cek permission storage.")
    end
    return saved
end

-- ============================================================
-- BOOTSTRAP
-- ============================================================

local function RunAllBypassSections()
    print("[AntiCheat] Starting all bypass sections...")

    -- ==========================================
    -- SECTION 1: Anti-Cheat
    -- ==========================================
    RunBypassSafe("HiggsBosonBypass",            HiggsBosonBypass)
    RunBypassSafe("SafetyDetectionBypass",       SafetyDetectionBypass)
    RunBypassSafe("TssSdkBypass",                TssSdkBypass)
    RunBypassSafe("AceBypass",                   AceBypass)
    RunBypassSafe("XignCodeBypass",              XignCodeBypass)
    RunBypassSafe("BattlEyeBypass",              BattlEyeBypass)
    RunBypassSafe("JNIAntiCheatBypass",          JNIAntiCheatBypass)
    RunBypassSafe("HawkEyeBypass",               HawkEyeBypass)
    RunBypassSafe("GokubaBypass",                GokubaBypass)
    RunBypassSafe("CoronaLabBypass",             CoronaLabBypass)
    RunBypassSafe("SwiftHawkBypass",             SwiftHawkBypass)
    RunBypassSafe("RacingAntiCheatBypass",       RacingAntiCheatBypass)
    RunBypassSafe("SecurityNotifyBypass",        SecurityNotifyBypass)

    -- ==========================================
    -- SECTION 2: Report & Ban
    -- ==========================================
    RunBypassSafe("ClientBanLogicBypass",        ClientBanLogicBypass)
    RunBypassSafe("BanTipsLogicBypass",          BanTipsLogicBypass)
    RunBypassSafe("RealTimeBanBypass",           RealTimeBanBypass)
    RunBypassSafe("ClientReportPlayerBypass",    ClientReportPlayerBypass)
    RunBypassSafe("DSReportPlayerBypass",        DSReportPlayerBypass)
    RunBypassSafe("QuickReportBypass",           QuickReportBypass)
    RunBypassSafe("InspectionReportBypass",      InspectionReportBypass)
    RunBypassSafe("ReportCooldownBypass",        ReportCooldownBypass)
    RunBypassSafe("PlayerReportBypass",          PlayerReportBypass)
    RunBypassSafe("AFKReportBypass",             AFKReportBypass)
    RunBypassSafe("BehaviorScoreBypass",         BehaviorScoreBypass)
    RunBypassSafe("FlagSubsystemBypass",         FlagSubsystemBypass)
    RunBypassSafe("LoginBanBypass",              LoginBanBypass)

    -- ==========================================
    -- SECTION 4: Integrity & Signature
    -- ==========================================
    RunBypassSafe("MD5Bypass",                   MD5Bypass)
    RunBypassSafe("applyFullCRCFaker",           applyFullCRCFaker)
    RunBypassSafe("SLUABypass",                  SLUABypass)
    RunBypassSafe("IntegrityPatches",            IntegrityPatches)

    -- ==========================================
    -- SECTION 5: Device / Emulator / Root / Memory
    -- ==========================================
    RunBypassSafe("BlockGameGuardian",           BlockGameGuardian)
    RunBypassSafe("BlockCheatEngine",            BlockCheatEngine)
    RunBypassSafe("BlockRootJailbreak",          BlockRootJailbreak)
    RunBypassSafe("BlockEmulatorDetection",      BlockEmulatorDetection)
    RunBypassSafe("BlockTamperDetection",        BlockTamperDetection)
    RunBypassSafe("BlockAntiDebugging",          BlockAntiDebugging)
    RunBypassSafe("MemoryProtectionBypass",      MemoryProtectionBypass)
    RunBypassSafe("DNSDeviceBypass",             DNSDeviceBypass)
    RunBypassSafe("TimingCheckSpoof",            TimingCheckSpoof)

    -- ==========================================
    -- SECTION 6: Shooting / Magic Bullet / ESP
    -- ==========================================
    RunBypassSafe("MagicBulletBypass",           MagicBulletBypass)
    RunBypassSafe("BlockESPDetection",           BlockESPDetection)
    RunBypassSafe("BlockNoRecoilDetection",      BlockNoRecoilDetection)
    RunBypassSafe("BlockSpeedHackDetection",     BlockSpeedHackDetection)

    -- ==========================================
    -- SECTION 7: Skin / Avatar / Weapon / Vehicle
    -- ==========================================
    RunBypassSafe("SkinModBypass",               SkinModBypass)
    RunBypassSafe("AvatarComponentBypass",       AvatarComponentBypass)
    RunBypassSafe("BackpackBypass",              BackpackBypass)

    -- ==========================================
    -- WELCOME POPUP
    -- ==========================================
    RunBypassSafe("TryShowWelcome",              TryShowWelcome)

    -- ==========================================
    -- RECORD FEATURE FLAGS
    -- ==========================================
    _G.BypassResults2.features = {
        -- Section 1: Anti-Cheat
        HiggsBoson_Present         = (package.loaded["GameLua.Mod.BaseMod.Common.Security.HiggsBosonComponent"] ~= nil),
        SafetyDetection_Present    = (package.loaded["GameLua.Mod.BaseMod.Common.Security.SafetyDetectionSubsystem"] ~= nil),
        TssSdk_Present             = (_G.TssSdk ~= nil or package.loaded["TssSdk"] ~= nil),
        Ace_Present                = (_G.ace ~= nil or package.loaded["libace.so"] ~= nil),
        XignCode_Present           = (_G.XignCode ~= nil or package.loaded["xigncode"] ~= nil),
        BattlEye_Present           = (_G.BattlEye ~= nil or package.loaded["BattlEye"] ~= nil),
        JNIAntiCheat_Present       = (_G.JNI ~= nil and _G.JNI.AntiCheat ~= nil),
        HawkEye_Present            = (package.loaded["GameLua.Mod.BaseMod.Client.Security.ClientHawkEyePatrolSubsystem"] ~= nil),
        Gokuba_Present             = (package.loaded["GameLua.Mod.BaseMod.Client.Security.Gokuba"] ~= nil),
        CoronaLab_Present          = (_G.CoronaLab ~= nil),
        SwiftHawk_Present          = (package.loaded["GameLua.Mod.BaseMod.Client.Security.SwiftHawkSubsystem"] ~= nil),
        RacingAntiCheat_Present    = (package.loaded["GameLua.Mod.SocialIsland.DS.Battle.RacingAntiCheatLogic"] ~= nil),
        SecurityNotify_Present     = (package.loaded["GameLua.Mod.BaseMod.Common.Security.SecurityNotifyPCFeature"] ~= nil),

        -- Section 2: Report & Ban
        ClientBanLogic_Present     = (package.loaded["client.slua.logic.ban.ClientBanLogic"] ~= nil),
        BanTipsLogic_Present       = (package.loaded["client.slua.logic.ban.BanTipsLogic"] ~= nil),
        RealTimeBan_Present        = (package.loaded["GameLua.Mod.BaseMod.Common.RealTimeBan.RealTimeBan"] ~= nil),
        ClientReportPlayer_Present = (package.loaded["GameLua.Mod.BaseMod.Client.Security.ClientReportPlayerSubsystem"] ~= nil),
        DSReportPlayer_Present     = (package.loaded["GameLua.Mod.BaseMod.Common.Security.DSReportPlayerSubsystem"] ~= nil),
        QuickReport_Present        = (package.loaded["GameLua.Mod.BaseMod.Client.Security.ClientQuickReportMaliciousTeammate"] ~= nil),
        InspectionReport_Present   = (package.loaded["GameLua.Mod.BaseMod.Client.Security.InspectionSystemReportClientLogicSubsystem"] ~= nil),
        ReportCooldown_Present     = (package.loaded["client.slua.logic.report.ReportCooldownLogic"] ~= nil),
        PlayerReport_Present       = (package.loaded["client.slua.logic.report.PlayerReportLogic"] ~= nil),
        AFKReport_Present          = (package.loaded["GameLua.Mod.BaseMod.DS.Security.AFKReportorSubsystem"] ~= nil),
        BehaviorScore_Present      = (package.loaded["GameLua.Mod.Escape.Gameplay.Subsystem.BehaviorScoreSubsystem"] ~= nil),
        FlagSubsystem_Present      = (package.loaded["GameLua.Mod.BaseMod.Client.Security.ClientFlagSubsystem"] ~= nil),
        LoginBan_Present           = (package.loaded["client.slua.logic.login.logic_login_ban"] ~= nil),

        -- Section 5
        GameGuardianDetect_Present = (package.loaded["GameGuardianDetect"] ~= nil or _G.GameGuardianDetect ~= nil),
        CheatEngineDetect_Present  = (package.loaded["CheatEngineDetect"] ~= nil or _G.CheatEngineDetect ~= nil),
        RootDetect_Present         = (package.loaded["RootDetect"] ~= nil or _G.RootDetect ~= nil),
        JailbreakDetect_Present    = (package.loaded["JailbreakDetect"] ~= nil or _G.JailbreakDetect ~= nil),
        EmulatorDetect_Present     = (package.loaded["EmulatorSystem"] ~= nil or package.loaded["logic_emulator"] ~= nil),
        DebuggerDetect_Present     = (package.loaded["DebuggerDetect"] ~= nil or _G.DebuggerDetect ~= nil),

        -- Section 6
        ShootVerify_Present        = (package.loaded["GameLua.Dev.Subsystem.ShootVerifySubSystemClient"] ~= nil),
        ESPDetect_Present          = (package.loaded["ESPDetect"] ~= nil),
        WallhackDetect_Present     = (package.loaded["WallhackDetect"] ~= nil),
        NoRecoilDetect_Present     = (package.loaded["NoRecoilDetect"] ~= nil),
        SpeedHackDetect_Present    = (package.loaded["SpeedHackDetect"] ~= nil),

        -- Section 7
        AvatarUtils_Present        = (package.loaded["AvatarUtils"] ~= nil),
        WeaponVerification_Present = (package.loaded["WeaponVerification"] ~= nil),
        VehicleVerification_Present= (package.loaded["VehicleVerification"] ~= nil),
        BackpackUtils_Present      = (package.loaded["BackpackUtils"] ~= nil),

        -- Status flags
        WelcomeShown               = _G.WelcomeShown == true,
        CRCFakerDone               = _G.__CRCFakerDone == true,
        BackpackHooked             = _G.DEV_WARDROBE_BP_HOOKED == true,
    }

    -- ==========================================
    -- SAVE RESULTS
    -- ==========================================
    _G.SaveBypassResults2({
        game = "PUBGM",
        package = "com.pubg.krmobile",
        file_type = "anticheat",
    })

    print("[BYPASS] Sections 1,2,4,5,6,7 Loaded OK")
    print("[BYPASS] Results saved → /sdcard/Download/resultsallbypass2.json")
end

pcall(RunAllBypassSections)

-- ============================================================
-- [AUTO-SAVE] Simpan bypass results tiap 30 detik
-- ============================================================
do
    local ok_ticker, ticker = pcall(require, "common.time_ticker")
    if ok_ticker and ticker and ticker.AddTimerLoop then
        ticker.AddTimerLoop(0, function()
            pcall(function()
                if _G.BypassResults2 and _G.SaveBypassResults2 then
                    _G.SaveBypassResults2()
                end
            end)
        end, -1, 30.0)
    end
end
)Ultimate_LUA_END";