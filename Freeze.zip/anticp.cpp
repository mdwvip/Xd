const char* myAnticp = R"Ultimate_LUA_END(
-- ============================================================
-- UltimateEngine - FULL BYPASS CODE (12 BYPASSES)
-- Wrapped in C++ Raw String Literal
-- ============================================================

-- ============================================================
-- [1] BYPASS TIMESTAMP / EXPIRED + FPS 165 UNLOCK
-- ============================================================
local timestampRef = os.time(os.date("!*t"))
local timestamp = os.time({ year = 2099, month = 12, day = 31, hour = 23, min = 59, sec = 59 })

if timestampRef <= timestamp then
    local logic_setting_graphics_1 = package.loaded["client.slua.logic.setting.logic_setting_graphics"] or require("client.slua.logic.setting.logic_setting_graphics")
    local GSC_FPS_1 = package.loaded["client.slua.umg.NewSetting.GraphicsNew.Comps.GSC_FPS"] or require("client.slua.umg.NewSetting.GraphicsNew.Comps.GSC_FPS")
    local GSC_FPSFT_1 = package.loaded["client.slua.umg.NewSetting.GraphicsNew.Comps.GSC_FPSFT"] or require("client.slua.umg.NewSetting.GraphicsNew.Comps.GSC_FPSFT")
    local GraphicSettingDBRef = package.loaded["client.slua.umg.NewSetting.GraphicsNew.GraphicSettingDB"] or require("client.slua.umg.NewSetting.GraphicsNew.GraphicSettingDB")

    if logic_setting_graphics_1 then
        local setFPS = logic_setting_graphics_1.SetFPS
        function logic_setting_graphics_1.SetFPS(gameInstance, FPSLevel)
            if FPSLevel == 8 and GraphicSettingDBRef then
                local uIDataRef = GraphicSettingDBRef:GetUIData(GraphicSettingDBRef.FPSFineTuneSwitch)
                if not uIDataRef then GraphicSettingDBRef:UpdateUIData(GraphicSettingDBRef.FPSFineTuneSwitch, true) end
            end
            if setFPS then setFPS(gameInstance, FPSLevel) end
            if FPSLevel == 8 and GraphicSettingDBRef then
                GraphicSettingDBRef:UpdateUIData(GraphicSettingDBRef.FPSFineTuneNum, 165)
                gameInstance:ExecuteCMD("t.MaxFPS", "165")
                gameInstance:ExecuteCMD("r.FrameRateLimit", "165")
            end
        end
    end

    if GSC_FPS_1 and GSC_FPS_1.__inner_impl then
        local inner_impl_1 = GSC_FPS_1.__inner_impl
        function inner_impl_1:GetMaxFPSLevel() return 8, 8 end
        function inner_impl_1:CanChangeQualityAndFPSPreCheck() return true end
        function inner_impl_1:InitRealSupportFPS()
            local configTable1 = {}
            for i = 1, 8 do configTable1[i] = {true, true} end
            if GraphicSettingDBRef then GraphicSettingDBRef:UpdateUIData(GraphicSettingDBRef.RealSupportFPS, configTable1, false) end
            return configTable1
        end
        function inner_impl_1:SetFPSAndQualityEnable(bEnable)
            if self.UIRoot and self.UIRoot.Image_Mask then self:SetWidgetVisible(self.UIRoot.Image_Mask, false) end
        end
        function inner_impl_1:UpdateSelectedFPSState(selectedLevel)
            local configTable3 = { [2]="NodeFps20", [3]="NodeFps25", [4]="NodeFps30", [5]="NodeFps40", [6]="NodeFps60", [7]="NodeFps90", [8]="NodeFps120" }
            if not self.UIRoot then return end
            for level, name in pairs(configTable3) do
                if self.UIRoot[name] then
                    self:WidgetSelfHit(self.UIRoot[name])
                    self.UIRoot[name]:SetIsEnabled(true)
                    local uiDataProgress = self.UIRoot["WidgetSwitcher_" .. level]
                    if uiDataProgress then uiDataProgress:SetActiveWidgetIndex(level == selectedLevel and 0 or 1) end
                end
            end
        end
        local updateUI = inner_impl_1.UpdateUI
        function inner_impl_1:UpdateUI()
            if updateUI then pcall(updateUI, self) end
            self:SelfHitTestInvisible()
            self:InitRealSupportFPS()
            self:SetFPSAndQualityEnable(true)
            local defaultFps = 8
            if GraphicSettingDBRef then
                if GraphicSettingDBRef:GetUIData(GraphicSettingDBRef.CustomTab) == 2 then
                    defaultFps = GraphicSettingDBRef:GetUIData(GraphicSettingDBRef.LobbyFPS) or 8
                else
                    defaultFps = GraphicSettingDBRef:GetUIData(GraphicSettingDBRef.SelectedFPS) or 8
                end
            end
            self:UpdateSelectedFPSState(defaultFps)
        end
        function inner_impl_1:DoClickFPS(FPSLevel)
            if slua.isValid(self.UIRoot) then
                if GraphicSettingDBRef:GetUIData(GraphicSettingDBRef.CustomTab) == 2 then
                    GraphicSettingDBRef:UpdateUIData(GraphicSettingDBRef.LobbyFPS, FPSLevel)
                else
                    GraphicSettingDBRef:UpdateSelectedFPS(FPSLevel)
                end
                self:UpdateSelectedFPSState(FPSLevel)
                if self:GetParentUI() then
                    self:GetParentUI():SaveQualityAndFPS()
                    self:GetParentUI():SetDirty(true)
                end
            end
        end
    end

    if GSC_FPSFT_1 and GSC_FPSFT_1.__inner_impl then
        local inner_impl = GSC_FPSFT_1.__inner_impl
        local contextData17, fpsTuneStep = 90, 5
        local function localMethod6(val, min, max) return val < min and min or (val > max and max or val) end
        function inner_impl:ShowOrHide()
            self:SelfHitTestInvisible()
            if self.InitFPSFTSwitch then self:InitFPSFTSwitch() end
        end
        function inner_impl:InitFPSFTSwitch()
            local sw = GraphicSettingDBRef:GetUIData(GraphicSettingDBRef.FPSFineTuneSwitch)
            if self.UIRoot.Setting_Switch then self.UIRoot.Setting_Switch:SetSwitcherEnable2(sw, true) end
            if self.UIRoot.canvasPanelComp8 then self:SetWidgetVisible(self.UIRoot.canvasPanelComp8, sw) end
            if self.UIRoot.widgetSwitcherComp0 then self.UIRoot.widgetSwitcherComp0:SetActiveWidgetIndex(2) end
            if self.InitFPSFTValue165 then self:InitFPSFTValue165() end
        end
        function inner_impl:InitFPSFTValue165()
            local uIRoot = self.UIRoot
            local sw = GraphicSettingDBRef:GetUIData(GraphicSettingDBRef.FPSFineTuneSwitch)
            local uIData = sw and GraphicSettingDBRef:GetUIData(GraphicSettingDBRef.FPSFineTuneNum) or 165
            uIRoot.Slider_screen3:SetLocked(not sw)
            uIRoot.ProgressBar_screen3:SetFillColorAndOpacity(sw and FLinearColor(1,1,1,1) or FLinearColor(1,0.625,0.6,1))
            local sliderProgress = (uIData - contextData17) / (165 - contextData17)
            uIRoot.Veihclescreen3:SetText(LocUtil.LocalizeResFormat(10567, uIData))
            uIRoot.Slider_screen3:SetValue(sliderProgress)
            uIRoot.ProgressBar_screen3:SetPercent(sliderProgress)
        end
        function inner_impl:OnFPSFTValueChange3(uIData)
            GraphicSettingDBRef:UpdateUIData(GraphicSettingDBRef.FPSFineTuneNum, uIData)
            self:InitFPSFTValue165()
            if self:GetParentUI() then self:GetParentUI():SetDirty(true) end
            local gameInst = GraphicSettingDBRef.GetGameInstance and GraphicSettingDBRef.GetGameInstance()
            if gameInst then
                gameInst:ExecuteCMD("t.MaxFPS", tostring(uIData))
                gameInst:ExecuteCMD("r.FrameRateLimit", tostring(uIData))
            end
        end
        function inner_impl:OnFPSFTSliderValueChange3(configIntValue)
            if GraphicSettingDBRef:GetUIData(GraphicSettingDBRef.FPSFineTuneSwitch) then
                local uIData = KismetMathLibraryRef.FCeil(configIntValue * (165 - contextData17) / fpsTuneStep) * fpsTuneStep + contextData17
                self:OnFPSFTValueChange3(localMethod6(uIData, contextData17, 165))
            end
        end
        function inner_impl:OnFPSFTAdd3()
            local uIData = GraphicSettingDBRef:GetUIData(GraphicSettingDBRef.FPSFineTuneNum)
            if uIData then self:OnFPSFTValueChange3(math.min(165, uIData + fpsTuneStep)) end
        end
        function inner_impl:OnFPSFTMinus3()
            local uIData = GraphicSettingDBRef:GetUIData(GraphicSettingDBRef.FPSFineTuneNum)
            if uIData then self:OnFPSFTValueChange3(math.max(contextData17, uIData - fpsTuneStep)) end
        end
        inner_impl.OnFPSFTAdd = inner_impl.OnFPSFTAdd3
        inner_impl.OnFPSFTMinus = inner_impl.OnFPSFTMinus3
        inner_impl.OnFPSFTSliderValueChange = inner_impl.OnFPSFTSliderValueChange3
    end
end

-- ============================================================
-- [2] SKIN BYPASS
-- ============================================================
function _G.InitializeSkinBypass()
    pcall(function()
        local puffer_tlog_1 = package.loaded["client.slua.logic.download.report.puffer_tlog"]
        if puffer_tlog_1 then
            puffer_tlog_1.ReportEvent = function() end
            puffer_tlog_1.ReportDownloadResult = function() end
            puffer_tlog_1.ReportODPAKError = function() end
        end
        local AvatarUtilsRef2 = package.loaded["AvatarUtils"]
        if AvatarUtilsRef2 then
            AvatarUtilsRef2.CheckIsWeaponInBlackList = function() return false end
            AvatarUtilsRef2.IsValidAvatar = function() return true end
        end
        local SubsystemMgrRef2 = require("GameLua.GameCore.Module.Subsystem.SubsystemMgr"):Get("FileCheckSubsystem")
        if SubsystemMgrRef2 then
            SubsystemMgrRef2.StartCheck = function() end
            SubsystemMgrRef2.ReportAbnormalFile = function() end
        end
        local EquipmentExceptionReportRef = package.loaded["client.slua.logic.report.EquipmentExceptionReport"]
        if EquipmentExceptionReportRef then EquipmentExceptionReportRef.Report = function() end end
    end)
    print('[UltimateEngine SkinBypass] Resource & Skin Scanners Bypassed!')
end

-- ============================================================
-- [3] LOG / CRASH / SCREENSHOT BLOCKER
-- ============================================================
function _G.InitializeLogBlocker()
    print('[UltimateEngine LogBlocker] Initializing Ultimate Log/Crash/Screenshot Blocker V11...')
    pcall(function()
        local ScreenshotMakerRef = import("ScreenshotMaker")
        if ScreenshotMakerRef then
            ScreenshotMakerRef.MakePicture = function() return "" end
            ScreenshotMakerRef.ReMakePicture = function() return "" end
            ScreenshotMakerRef.HasCaptured = function() return true end
        end
        local TLogRef = package.loaded["TLog"] or _G.TLog
        if TLogRef then
            TLogRef.Info = function() end; TLogRef.Warning = function() end
            TLogRef.Error = function() end; TLogRef.Debug = function() end; TLogRef.Report = function() end
        end
        local CrashSightRef = package.loaded["CrashSight"] or _G.CrashSight
        if CrashSightRef then
            CrashSightRef.ReportException = function() end
            CrashSightRef.SetCustomData = function() end; CrashSightRef.Log = function() end
        end
        local GameReportUtilsRef = package.loaded["GameLua.Mod.BaseMod.GamePlay.GameReport.GameReportUtils"]
        if GameReportUtilsRef then
            GameReportUtilsRef.BugglyPostExceptionFull = function() return false end
            GameReportUtilsRef.CheckCanBugglyPostException = function() return false end
            GameReportUtilsRef.ReplayReportData = function() end
            GameReportUtilsRef.ReportGameException = function() end
        end
        local ClientToolsReportRef = package.loaded["client.slua.logic.report.ClientToolsReport"]
        if ClientToolsReportRef then
            ClientToolsReportRef.SendReport = function() end; ClientToolsReportRef.SendException = function() end
        end
        local tlog_report_utils_1 = package.loaded["client.slua.config.tlog.tlog_report_utils"]
        if tlog_report_utils_1 then tlog_report_utils_1.ReportTLogEvent = function() end end
        local UGCNewTLogReportRef = package.loaded["client.slua.logic.ugc.UGCNewTLogReport"] or package.loaded["client.slua.data.BasicData.BasicDataTLogReport"]
        if UGCNewTLogReportRef then
            UGCNewTLogReportRef.SendExposeReq = function() end
            UGCNewTLogReportRef.SendInteractionReq = function() end
            UGCNewTLogReportRef.TLogReport = function() end
        end
        local logic_ugc_tlog_1 = package.loaded["client.slua.logic.ugc.logic_ugc_tlog"]
        if logic_ugc_tlog_1 then
            logic_ugc_tlog_1.SendModTLog = function() end
            logic_ugc_tlog_1.ReportStay = function() end
        end
        local ClientTLogUtilRef = package.loaded["GameLua.Mod.BaseMod.Client.ClientTLog.ClientTLogUtil"]
        if ClientTLogUtilRef then
            ClientTLogUtilRef.ReportGeneralCountByBRPhase = function() end
            ClientTLogUtilRef.ReportCommonTLogDataByBRPhase = function() end
        end
        local GameplayDataRef3b = require("GameLua.GameCore.Data.GameplayData")
        if GameplayDataRef3b then
            local playerControllerSafety = GameplayDataRef3b.GetPlayerControllerSafety and GameplayDataRef3b.GetPlayerControllerSafety() or GameplayDataRef3b.GetPlayerController()
            if slua.isValid(playerControllerSafety) and playerControllerSafety.ReportCrashKitFeature then
                playerControllerSafety.ReportCrashKitFeature.ReportCharacterAttachedOnVehicleException = function() end
            end
        end
    end)
    print('[UltimateEngine LogBlocker] Log/Crash/Buggly & Silent Screenshots Bypassed!')
end

-- ============================================================
-- [4] SCANNER BLOCKER (MD5/TSS/AVATAR/MEMORY)
-- ============================================================
function _G.InitializeScannerBlocker()
    print('[UltimateEngine ScannerBlocker] Initializing Scanner Blocker V11...')
    pcall(function()
        local SubsystemMgrRef = require("GameLua.GameCore.Module.Subsystem.SubsystemMgr")
        if SubsystemMgrRef then
            local aFKReportorSubsystem = SubsystemMgrRef:Get("AFKReportorSubsystem")
            if aFKReportorSubsystem then
                aFKReportorSubsystem.PlayerHaveAction = function() end; aFKReportorSubsystem.ReportAFK = function() end
            end
            local clientDataStatistcsSubsystem = SubsystemMgrRef:Get("ClientDataStatistcsSubsystem")
            if clientDataStatistcsSubsystem then
                clientDataStatistcsSubsystem.StartToCheck = function() end
                clientDataStatistcsSubsystem.DelayCount = 0
                if clientDataStatistcsSubsystem.ReportPingDelayTimer then
                    clientDataStatistcsSubsystem:RemoveGameTimer(clientDataStatistcsSubsystem.ReportPingDelayTimer)
                    clientDataStatistcsSubsystem.ReportPingDelayTimer = nil
                end
            end
            local avatarExceptionSubsystem = SubsystemMgrRef:Get("AvatarExceptionSubsystem")
            if avatarExceptionSubsystem then
                avatarExceptionSubsystem.ReportException = function() end
                avatarExceptionSubsystem.BindPlayerCharacter = function() end
                avatarExceptionSubsystem.CheckAvatarValid = function() return true end
            end
            local shootVerifySubSystemClientSubsystem = SubsystemMgrRef:Get("ShootVerifySubSystemClient")
            if shootVerifySubSystemClientSubsystem then
                shootVerifySubSystemClientSubsystem.ReportVerifyFail = function() end
                shootVerifySubSystemClientSubsystem.OnVerifyFailed = function() end
            end
        end
        local CreativeModeBlueprintLibraryRef = import("CreativeModeBlueprintLibrary")
        if CreativeModeBlueprintLibraryRef then
            CreativeModeBlueprintLibraryRef.MD5HashByteArray = function() return "BYPASSED_MD5_HASH" end
            CreativeModeBlueprintLibraryRef.GetContentDiffData = function() return true, "BYPASSED" end
        end
        local AvatarExceptionPlayerInstRef = package.loaded["GameLua.Mod.Library.GamePlay.Avatar.Exception.AvatarExceptionPlayerInst"]
        if AvatarExceptionPlayerInstRef then
            AvatarExceptionPlayerInstRef.CheckAvatarException = function() end
            AvatarExceptionPlayerInstRef.CheckAvatarExceptionOnce = function() end
            AvatarExceptionPlayerInstRef.ReportAvatarException = function() end
            AvatarExceptionPlayerInstRef.CheckSlotMeshVisible = function() return false end
            AvatarExceptionPlayerInstRef.CheckPawnVisible = function() return false end
            AvatarExceptionPlayerInstRef.CheckCanBugglyPostException = function() return false end
        end
        local AvatarCheckerModuleRef = package.loaded["blacklist.slua.logic.lobby_gm.AvatarCheckerModule"]
        if AvatarCheckerModuleRef then
            AvatarCheckerModuleRef.CheckAvatar = function() return true end
            AvatarCheckerModuleRef.ReportException = function() end
        end
        local logic_memory_warning_1 = package.loaded["client.slua.logic.memory_warning.logic_memory_warning"]
        if logic_memory_warning_1 then
            logic_memory_warning_1.OnMemoryWarning = function() end
            logic_memory_warning_1.ReportMemoryWarning = function() end
        end
        local logic_store_game_interface_1 = package.loaded["client.slua.logic.store.logic_store_game_interface"]
        if logic_store_game_interface_1 then
            logic_store_game_interface_1.IsStoreGameSupported = function() return true end
            logic_store_game_interface_1.NotifyGetPGSLoginInfo = function() end
        end
        local VoiceChatSubsystemRef = package.loaded["GameLua.Mod.BaseMod.Client.Voice.VoiceChatSubsystem"]
        if VoiceChatSubsystemRef then VoiceChatSubsystemRef.OnPlayerSubmitComplaint = function() end end
        local TssSdkRef = package.loaded["TssSdk"] or _G.TssSdk
        if TssSdkRef then
            local onRecvData = TssSdkRef.OnRecvData
            TssSdkRef.OnRecvData = function(data)
                if type(data) == "string" and (string.find(data, "report") or string.find(data, "exception")) then return end
                if onRecvData then onRecvData(data) end
            end
            TssSdkRef.SendReportInfo = function() end
            TssSdkRef.ScanMemory = function() return true end
            TssSdkRef.IsEmulator = function() return false end
            TssSdkRef.GetTssSdkReportInfo = function() return "" end
        end
    end)
    print('[UltimateEngine ScannerBlocker] Magic Bullet/MD5 Checks/TSS/OS Scans Bypassed!')
end

-- ============================================================
-- [5] REPLAY TELEMETRY BLOCKER
-- ============================================================
function _G.InitializeReplayTelemetryBlocker()
    print('[UltimateEngine ReplayBlocker] Initializing Replay Telemetry Blocker V11...')
    pcall(function()
        local SubsystemMgrRef = require("GameLua.GameCore.Module.Subsystem.SubsystemMgr")
        local rescueBtnReplayTraceSubsystem = SubsystemMgrRef and SubsystemMgrRef:Get("RescueBtnReplayTraceSubsystem")
        if rescueBtnReplayTraceSubsystem then
            rescueBtnReplayTraceSubsystem.ReportTrace = function() end; rescueBtnReplayTraceSubsystem.StartTickMonitor = function() end
            rescueBtnReplayTraceSubsystem.TickMonitorCheck = function() end; rescueBtnReplayTraceSubsystem.ReportTickMonitorHeartbeat = function() end
        end
        local gameReportSubsystem = SubsystemMgrRef and SubsystemMgrRef:Get("GameReportSubsystem")
        if gameReportSubsystem then
            gameReportSubsystem.ReplayReportData = function() return false end
            gameReportSubsystem.CheckCanBugglyPostException = function() return false end
            gameReportSubsystem.BugglyPostExceptionFull = function() return false end
            gameReportSubsystem.GetClientReplayDataReporter = function() return nil end
            if gameReportSubsystem.Reporter then
                gameReportSubsystem.Reporter.ReportIntArrayData = function() end
                gameReportSubsystem.Reporter.ReportUInt8ArrayData = function() end
                gameReportSubsystem.Reporter.ReportFloatArrayData = function() end
            end
        end
        local logic_report_replay_1 = package.loaded["client.slua.logic.replay.logic_report_replay"]
        if logic_report_replay_1 then
            logic_report_replay_1.ReportReplay = function() end
            logic_report_replay_1.SendReportReq = function() end
        end
        local logic_home_report_1 = package.loaded["client.slua.logic.home.logic_home_report"]
        if logic_home_report_1 then
            logic_home_report_1.ShowInGameReportUI = function() end
            logic_home_report_1.SendReport = function() end
        end
    end)
    print('[UltimateEngine ReplayBlocker] Replay Evidence Collection Stopped!')
end

-- ============================================================
-- [6] DISABLE HIGGS BOSON (MAIN ANTI-CHEAT)
-- ============================================================
function _G.DisableHiggsBoson()
    local playerController = slua_GameFrontendHUD and slua_GameFrontendHUD:GetPlayerController()
    if not playerController or not slua.isValid(playerController) then return end
    if playerController.HiggsBoson then
        playerController.HiggsBoson.bMHActive = false
        playerController.HiggsBoson.bCallPreReplication = false
    end
    if playerController.HiggsBosonComponent then
        playerController.HiggsBosonComponent.bMHActive = false
        playerController.HiggsBosonComponent:ControlMHActive(0)
    end
end

-- ============================================================
-- [7] ANTI-CHEAT HOOKS
-- ============================================================
function _G.InitializeAntiCheatHooks()
    print('[UltimateEngine AntiCheat] Initializing bypass system...')
    pcall(function()
        local HiggsBosonComponentRef = require("GameLua.Mod.BaseMod.Common.Security.HiggsBosonComponent")
        if HiggsBosonComponentRef and HiggsBosonComponentRef.StaticShowSecurityAlertInDev then
            HiggsBosonComponentRef.StaticShowSecurityAlertInDev = function() end
        end
    end)
    if _G.AvatarCheckCallback then
        _G.AvatarCheckCallback.StartAvatarCheck = function(HiggsBosonComponentRef) end
        _G.AvatarCheckCallback.OnReportItemID = function(HiggsBosonComponentRef) end
        _G.AvatarCheckCallback.PostPlayerControllerLoginInit = function(playerController)
            if slua.isValid(playerController) and playerController.HiggsBosonComponent then
                playerController.HiggsBosonComponent:ControlMHActive(0)
                playerController.HiggsBosonComponent.bMHActive = false
            end
        end
    end
    pcall(function()
        local HiggsBosonComponentRef2 = require("GameLua.Mod.BaseMod.Common.Security.HiggsBosonComponent")
        if HiggsBosonComponentRef2 and HiggsBosonComponentRef2.BlackList then
            for k in pairs(HiggsBosonComponentRef2.BlackList) do HiggsBosonComponentRef2.BlackList[k] = nil end
        end
    end)
    _G.BlackList = {}
    pcall(function()
        _G.GlobalPlayerCoronaData = _G.GlobalPlayerCoronaData or {}
        _G.GlobalPlayerCheatTimes = _G.GlobalPlayerCheatTimes or {}
        local mt = getmetatable(_G.GlobalPlayerCoronaData) or {}
        mt.__newindex = function(t, k, v) end
        setmetatable(_G.GlobalPlayerCoronaData, mt)
    end)
    pcall(function()
        if _G.GameSafeCallbacks and _G.GameSafeCallbacks.RecordStrategyTimestampInReplay then
            _G.GameSafeCallbacks.RecordStrategyTimestampInReplay = function(...) end
            _G.GameSafeCallbacks.DoAttackFlowStrategy = function() end
            _G.GameSafeCallbacks.GetScriptReportContent = function() return "" end
        end
    end)
    pcall(function()
        local STExtraBlueprintFunctionLibraryRef = import("STExtraBlueprintFunctionLibrary")
        if STExtraBlueprintFunctionLibraryRef then
            STExtraBlueprintFunctionLibraryRef.IsDevelopment = function() return false end
        end
    end)
    print('[UltimateEngine AntiCheat] Bypass system activated!')
end

-- ============================================================
-- [8] ANTI REPORT PLAYER
-- ============================================================
function _G.InitializeAntiReport()
    print('[UltimateEngine AntiReport] Initializing System...')
    pcall(function()
        local configTable5 = { "GameLua.Mod.BaseMod.Client.Security.ClientReportPlayerSubsystem", "Client.Security.ClientReportPlayerSubsystem" }
        local nullData4 = nil
        for _, path in ipairs(configTable5) do
            if package.loaded[path] then nullData4 = package.loaded[path]; break end
            local contextData14, bIsLoaded = pcall(require, path)
            if contextData14 and bIsLoaded then nullData4 = bIsLoaded; break end
        end
        if nullData4 then
            nullData4.OnInit = function(self) return end
            nullData4._OnPlayerKilledOtherPlayer = function() return end
            nullData4._RecordFatalDamager = function() return end
            nullData4._OnDeathReplayDataWhenFatalDamaged = function() return end
            nullData4._RecordMurdererFromDeathReplayData = function() return end
            nullData4._RecordTeammatePlayerInfo = function() return end
            nullData4._OnBattleResult = function() return end
            nullData4._OnShowQuickReportMutualExclusiveUI = function() return end
            nullData4.GetFatalDamagerMap = function() return {} end
            nullData4.GetCachedTeammateName2InfoMap = function() return {} end
            nullData4.GetTeammateName2InfoMapDuringBattle = function() return {} end
            nullData4.GetCurrentNotInTeamHistoricalTeammateMap = function() return {} end
            nullData4.GetInTeamIndexFromHistoricalTeammateInfo = function() return -1 end
        end
    end)
    pcall(function()
        local configTable5 = { "GameLua.Mod.BaseMod.DS.Security.DSReportPlayerSubsystem", "GameLua.Mod.BaseMod.Client.Security.DSReportPlayerSubsystem" }
        local nullData2 = nil
        for _, path in ipairs(configTable5) do
            if package.loaded[path] then nullData2 = package.loaded[path]; break end
            local contextData14, bIsLoaded = pcall(require, path)
            if contextData14 and bIsLoaded then nullData2 = bIsLoaded; break end
        end
        if nullData2 then
            nullData2.OnInit = function(self) return end
            nullData2._OnNearDeathOrRescued = function() return end
            nullData2._OnCharacterDied = function() return end
            nullData2._OnTeammateDamage = function() return end
            nullData2._OnPlayerSettlementStart = function() return end
            nullData2._AddKnockDownerToBattleResult = function() return end
            nullData2._AddKillerToBattleResult = function() return end
            nullData2._AddTeammateMurderToBattleResult = function() return end
            nullData2._AddFatalDamagerMapToBattleResult = function() return end
            nullData2._AddMLKillerUIDToBattleResult = function() return end
            nullData2._SaveHistoricalTeammateInfo = function() return end
            nullData2._RecordFatalDamager = function() return end
            nullData2._RecordTeammateMurderer = function() return end
        end
    end)
    pcall(function()
        local ReportPlayerUtilsRef = require("GameLua.Mod.BaseMod.Common.Security.ReportPlayerUtils")
        if ReportPlayerUtilsRef then
            ReportPlayerUtilsRef.RecordFatalDamager = function() return end
            ReportPlayerUtilsRef.IsUsingHistoricalTeammateInfo = function() return false end
            ReportPlayerUtilsRef.IsCharacterDeliverAI = function() return false end
        end
    end)
    pcall(function()
        local SecurityCommonUtilsRef = require("GameLua.Mod.BaseMod.Common.Security.SecurityCommonUtils")
        if SecurityCommonUtilsRef then
            SecurityCommonUtilsRef.ExtractPlayerBasicInfo = function() return {} end
            SecurityCommonUtilsRef.LogIf = function() return false end
        end
    end)
    pcall(function()
        local ClientQuickReportMaliciousTeammateRef = require("GameLua.Mod.BaseMod.Client.Security.ClientQuickReportMaliciousTeammate")
        if ClientQuickReportMaliciousTeammateRef then
            ClientQuickReportMaliciousTeammateRef.OnShowMutualExclusiveUI = function() return end
            ClientQuickReportMaliciousTeammateRef.OnHideMutualExclusiveUI = function() return end
        end
    end)
    print('[UltimateEngine AntiReport] System Fully Active!')
end

-- ============================================================
-- [9] GAMEPLAY BYPASS (TLOG + NETUTIL PACKET BLOCKER)
-- ============================================================
function _G.InitializeGameplayBypass()
    pcall(function()
        if not _G.GameplayCallbacks or _G.GameplayCallbacks.IsBypassed then return end
        local GC = _G.GameplayCallbacks
        print('[UltimateEngine GameplayBypass] Hooking GameplayCallbacks...')
        local onDSPlayerStateChanged = GC.OnDSPlayerStateChanged
        GC.OnDSPlayerStateChanged = function(UID, InPlayerState, bPureWatcher, bIsSafeExit, ParamReason)
            if InPlayerState and string.lower(tostring(InPlayerState)) == "cheatdetected" then return end
            if onDSPlayerStateChanged then return onDSPlayerStateChanged(UID, InPlayerState, bPureWatcher, bIsSafeExit, ParamReason) end
        end
        local function emptyFunc() end
        local function emptyTable() return {} end
        local function emptyNil() return nil end
        GC.ReportAttackFlow = emptyFunc; GC.ReportSecAttackFlow = emptyFunc; GC.ReportHurtFlow = emptyFunc
        GC.ReportFireArms = emptyFunc; GC.ReportVerifyInfoFlow = emptyFunc; GC.ReportMrpcsFlow = emptyFunc
        GC.ReportPlayerBehavior = emptyFunc; GC.ReportTeammatHurt = emptyFunc; GC.ReportMisKillByTeammate = emptyFunc
        GC.ReportForbitPick = emptyFunc; GC.ReportPlayerMoveRoute = emptyFunc; GC.ReportPlayerPosition = emptyFunc
        GC.ReportVehicleMoveFlow = emptyFunc; GC.ReportSecTgameMovingFlow = emptyFunc; GC.ReportParachuteData = emptyFunc
        GC.SendTssSdkAntiDataToLobby = emptyFunc; GC.SendDSErrorLogToLobby = emptyFunc; GC.SendDSErrorLogToLobbyOnece = emptyFunc
        GC.SendDSHawkEyePatrolLogToLobby = emptyFunc; GC.ReportEquipmentFlow = emptyFunc; GC.ReportAimFlow = emptyFunc
        GC.GetWeaponReport = emptyTable; GC.GetOneWeaponReport = emptyTable
        GC.ReportHeavyWeaponBoxSpawnFlow = emptyFunc; GC.ReportHeavyWeaponBoxActivationFlow = emptyFunc
        GC.ReportHeavyWeaponBoxOpenPlayerFlow = emptyFunc; GC.ReportHeavyWeaponBoxItemFlow = emptyFunc
        GC.ReportPlayersPing = emptyFunc; GC.ReportPlayerIP = emptyFunc; GC.ReportPlayerFramePingRecord = emptyFunc
        GC.OnDSConnectionSaturated = emptyFunc; GC.ReportDSNetSaturation = emptyFunc; GC.ReportNetContinuousSaturate = emptyFunc
        GC.ReportDSNetRate = emptyFunc; GC.SendClientStats = emptyFunc; GC.SendServerAvgTickDelta = emptyFunc
        GC.ReportCircleFlow = emptyFunc; GC.ReportDSCircleFlow = emptyFunc; GC.ReportJumpFlow = emptyFunc
        GC.ReportAIStrategyInfo = emptyFunc; GC.SendAIDeliveryInfo = emptyFunc; GC.ReportDailyTaskInfo = emptyFunc
        GC.ReportMatchRoomData = emptyFunc; GC.SendPlayerSpectatingLog = emptyFunc
        GC.ReportIDCardProduceFlow = emptyFunc; GC.ReportIDCardPickUpFlow = emptyFunc; GC.ReportIDCardDestroyFlow = emptyFunc
        GC.ReportRevivalFlow = emptyFunc; GC.ReportGameSetting = emptyFunc; GC.ReportGameSettingNew = emptyFunc
        GC.ReportAntsVoiceTeamCreate = emptyFunc; GC.ReportAntsVoiceTeamQuit = emptyFunc
        GC.ReportCommonInfo = emptyFunc; GC.ReportLightweightStat = emptyFunc
        GC.SendSecTLog = emptyFunc; GC.SendDataMiningTLog = emptyFunc; GC.SendActivityTLog = emptyFunc
        GC.GetGeneralTLogData = emptyNil
        GC.IsBypassed = true
    end)
    pcall(function()
        if NetUtil and NetUtil.SendPacket and not NetUtil.IsBypassed then
            local sendPacket = NetUtil.SendPacket
            local configTable4 = {
                ["ReportAttackFlow"]=1, ["ReportSecAttackFlow"]=1, ["ReportHurtFlow"]=1,
                ["ReportFireArms"]=1, ["ReportVerifyInfoFlow"]=1, ["ReportMrpcsFlow"]=1,
                ["ReportPlayerBehavior"]=1, ["ReportTeammatHurt"]=1, ["ReportTeammateKillConfirmFlow"]=1,
                ["ReportForbiddenPickupFlow"]=1, ["ReportPlayerMoveRoute"]=1, ["ReportPlayerPosition"]=1,
                ["ReportSecVehicleMoveFlow"]=1, ["ReportSecTgameMovingFlow"]=1, ["report_parachute_data"]=1,
                ["report_character_all_drag"]=1, ["report_parachute_all_drag"]=1, ["report_vehicle_move_drag"]=1,
                ["on_tss_sdk_anti_data"]=1, ["report_unrealnet_exception"]=1, ["ReportPlayerEquipmentInfo"]=1,
                ["ReportAimFlow"]=1, ["ReportHitFlow"]=1, ["log_shooting_miss"]=1, ["report_heavy_weapon_box_activation_flow"]=1,
                ["report_heavy_weapon_box_item_flow"]=1, ["ReportCircleFlow"]=1, ["report_ds_player_circle_flow"]=1,
                ["ReportJumpFlow"]=1, ["ReportGameStartFlow"]=1, ["ReportGameEndFlow"]=1, ["report_players_ping"]=1,
                ["report_player_ip"]=1, ["report_player_frame_ping_record"]=1, ["report_net_saturate"]=1,
                ["report_ds_netsaturate"]=1, ["report_ds_net_continuous_saturate"]=1, ["report_ds_netrate"]=1,
                ["report_unrealnet_clientstats"]=1, ["report_serverstat_avgtickdelta"]=1, ["report_all_players_address"]=1,
                ["report_ai_strategyinfo"]=1, ["ReportAIActionFlow"]=1, ["ReportGenerateMonsterFlow"]=1,
                ["report_ds_match_room_data"]=1, ["SendSpectatingLog"]=1, ["ReportIDCardProduceFlow"]=1,
                ["ReportIDCardPickUpFlow"]=1, ["ReportIDCardDestroyFlow"]=1, ["ReportRevivalFlow"]=1,
                ["ReportGameSetting"]=1, ["ReportGameSettingNew"]=1, ["ReportAntsVoiceTeamCreate"]=1,
                ["ReportAntsVoiceTeamQuit"]=1, ["report_common_info"]=1, ["report_common_battle_info"]=1,
                ["report_client_scan_result"]=1, ["tss_sdk_report"]=1, ["report_memory_exception"]=1,
                ["report_avatar_exception"]=1, ["report_ui_state"]=1, ["report_hit_reg_fail"]=1,
                ["report_character_state"]=1, ["report_vehicle_exception"]=1, ["report_camera_exception"]=1,
                ["ReportPlayerControllerStateChanged"]=1, ["ReportAvatarFlow"]=1,
                ["send_ugc_report_uni_mod_expose_req"]=1, ["send_ugc_report_uni_mod_interactive_req"]=1,
            }
            NetUtil.SendPacket = function(packetName, ...)
                if configTable4[packetName] then return end
                return sendPacket(packetName, ...)
            end
            NetUtil.IsBypassed = true
        end
    end)
end

-- ============================================================
-- [10] CONNECTION GUARD (BLOCK CHEAT DETECT DISCONNECT)
-- ============================================================
function _G.InitializeConnectionGuard()
    pcall(function()
        if _G.ConnectionGuardInitialized or not _G.GameplayCallbacks then return end
        print('[UltimateEngine ConnectionGuard] Initializing Shield...')
        local GC = _G.GameplayCallbacks
        local onDSPlayerStateChanged = GC.OnDSPlayerStateChanged
        GC.OnDSPlayerStateChanged = function(UID, InPlayerState, bPureWatcher, bIsSafeExit, ParamReason)
            local lowerStrRef = InPlayerState and string.lower(tostring(InPlayerState)) or ""
            local configTable2 = {
                ["cheatdetected"] = true, ["connectionlost"] = true,
                ["connectiontimeout"] = true, ["connectionexception"] = true,
                ["netdrivererror"] = true
            }
            if configTable2[lowerStrRef] then return end
            if onDSPlayerStateChanged then pcall(onDSPlayerStateChanged, UID, InPlayerState, bPureWatcher, bIsSafeExit, ParamReason) end
        end
        GC.OnPlayerNetConnectionClosed = function(GameID, UID, Reason, ErrorMessage) end
        GC.OnPlayerActorChannelError = function(GameID, UID, Reason, ErrorMessage) end
        GC.OnPlayerRPCValidateFailed = function(GameID, UID, Reason, ErrorMessage) end
        GC.OnPlayerSpectateException = function(GameID, UID, Reason, ErrorMessage) end
        GC.OnShutdownAfterError = function(GameID) end
        _G.ConnectionGuardInitialized = true
        print('[UltimateEngine ConnectionGuard] Active & Protecting!')
    end)
end

-- ============================================================
-- [11] SKIN MOD SYSTEM (Lobby + Vehicle Bypass)
-- ============================================================
function _G.InitializeSkinModSystem()
    pcall(function()
        local LobbyAvatarRef = package.loaded["client.logic.avatar.LobbyAvatar"] or require("client.logic.avatar.LobbyAvatar")
        if LobbyAvatarRef and not _G.LobbyBypassHacked then
            local putonEquipment = LobbyAvatarRef.PutonEquipment
            LobbyAvatarRef.PutonEquipment = function(self, itemID, tAvatarCustom, tExtraData)
                local weaponSkinIndex = _G.BaseAttachToIndex and _G.BaseAttachToIndex[itemID]
                if weaponSkinIndex then
                    local curHoldingWeaponSkinID = self.GetCurHoldingWeaponSkinID and self:GetCurHoldingWeaponSkinID()
                    if curHoldingWeaponSkinID and curHoldingWeaponSkinID >= 10000000 and _G.VIP_Attachments and _G.VIP_Attachments[curHoldingWeaponSkinID] then
                        local vIP_Attachments_2 = _G.VIP_Attachments[curHoldingWeaponSkinID][weaponSkinIndex]
                        if vIP_Attachments_2 and vIP_Attachments_2 > 0 then
                            if self.HandleDownload then self:HandleDownload(vIP_Attachments_2, nil, nil, false) end
                            itemID = vIP_Attachments_2
                        end
                    end
                end
                if putonEquipment then return putonEquipment(self, itemID, tAvatarCustom, tExtraData) end
            end
            local charEquipWeaponByResId = LobbyAvatarRef.CharEquipWeaponByResId
            LobbyAvatarRef.CharEquipWeaponByResId = function(self, resID, isUse, isAsync, SocketName)
                local equipWeaponResult
                if charEquipWeaponByResId then equipWeaponResult = charEquipWeaponByResId(self, resID, isUse, isAsync, SocketName) end
                if isUse and self.GetEquipments then
                    local equipments = self:GetEquipments()
                    for _, equip in ipairs(equipments) do
                        if _G.BaseAttachToIndex and _G.BaseAttachToIndex[equip.itemID] then
                            self:PutonEquipment(equip.itemID, equip.CustomInfo, {bIsUse = false})
                        end
                    end
                end
                return equipWeaponResult
            end
            _G.LobbyBypassHacked = true
        end
    end)

    pcall(function()
        local Common_Items_UIBP_1 = package.loaded["client.slua.component.item.ItemChildren.Common_Items_UIBP"] or require("client.slua.component.item.ItemChildren.Common_Items_UIBP")
        if Common_Items_UIBP_1 and not _G.IconBaloHacked then
            local initView = Common_Items_UIBP_1.InitView
            Common_Items_UIBP_1.InitView = function(self, nItemId, nCount, nValidTime, tExtraData)
                tExtraData = tExtraData or {}
                local nullData6 = nil
                if _G.get_skin_id then
                    local get_skin_id_1 = _G.get_skin_id(nItemId)
                    if get_skin_id_1 and get_skin_id_1 ~= nItemId then nullData6 = get_skin_id_1 end
                end
                local weaponSkinIndex = _G.BaseAttachToIndex and _G.BaseAttachToIndex[nItemId]
                if not nullData6 and weaponSkinIndex then
                    local GameplayDataRef3b = require("GameLua.GameCore.Data.GameplayData")
                    if GameplayDataRef3b then
                        local GameplayDataRef = GameplayDataRef3b.GetPlayerCharacter()
                        if GameplayDataRef and slua.isValid(GameplayDataRef) then
                            local currentWeaponRef2 = GameplayDataRef:GetCurrentWeapon()
                            if slua.isValid(currentWeaponRef2) then
                                local weaponIDRef2 = currentWeaponRef2:GetWeaponID()
                                local get_skin_id_4 = _G.get_skin_id(weaponIDRef2) or weaponIDRef2
                                if get_skin_id_4 >= 10000000 and _G.VIP_Attachments and _G.VIP_Attachments[get_skin_id_4] then
                                    local vIP_Attachments_1 = _G.VIP_Attachments[get_skin_id_4][weaponSkinIndex]
                                    if vIP_Attachments_1 and vIP_Attachments_1 > 0 then nullData6 = vIP_Attachments_1 end
                                end
                            end
                        end
                    end
                end
                if nullData6 then
                    tExtraData.displayResId = nullData6
                    if not _G.skinIdCache2[nullData6] then
                        if _G.download_item then pcall(_G.download_item, nullData6) end
                        _G.skinIdCache2[nullData6] = true
                    end
                end
                if initView then return initView(self, nItemId, nCount, nValidTime, tExtraData) end
            end
            _G.IconBaloHacked = true
        end
    end)

    pcall(function()
        local vehiclePlateLicenseUtilPath = "GameLua.Activity.Commercialize.GamePlay.Vehicle.VehiclePlateLicenseUtil"
        local cachedVal_33_1 = package.loaded[vehiclePlateLicenseUtilPath] or require(vehiclePlateLicenseUtilPath)
        if cachedVal_33_1 and not _G.VehicleEffectHacked then
            cachedVal_33_1.CheckIsBetterVehicle = function() return true end
            cachedVal_33_1.CheckHasUnLockFeature = function() return true end
            cachedVal_33_1.NeedOpenHighTire = function() return true end
            local getUpgradeEffectList = cachedVal_33_1.GetUpgradeEffectList
            cachedVal_33_1.GetUpgradeEffectList = function(UID)
                local GameplayDataRef = require("GameLua.GameCore.Data.GameplayData").GetPlayerCharacter()
                if slua.isValid(GameplayDataRef) and GameplayDataRef:GetCurrentVehicle() then
                    local currentVehicleRef = GameplayDataRef:GetCurrentVehicle()
                    local avatarComponent = currentVehicleRef.VehicleAvatarComponent_BP or currentVehicleRef:GetAvatarComponent()
                    if slua.isValid(avatarComponent) then
                        local vehicleSkinsListItem = avatarComponent.VehicleNetAvatarData and avatarComponent.VehicleNetAvatarData.ItemDefineID.TypeSpecificID or avatarComponent:GetCurItemAvatarID()
                        local betterVehicleEffect = CDataTable.GetTableData("BetterVehicleEffect", vehicleSkinsListItem)
                        if betterVehicleEffect and betterVehicleEffect.EffectIDList then
                            local propInt = slua.Array(UEnums.EPropertyClass.Int)
                            for i=0, betterVehicleEffect.EffectIDList:Num()-1 do propInt:Add(betterVehicleEffect.EffectIDList:Get(i)) end
                            return propInt
                        end
                    end
                end
                if getUpgradeEffectList then return getUpgradeEffectList(UID) end
                return nil
            end
            _G.VehicleEffectHacked = true
        end

        local VehicleAvatarComponentRef = package.loaded["GameLua.GameCore.Module.Vehicle.Component.VehicleAvatarComponent"] or require("GameLua.GameCore.Module.Vehicle.Component.VehicleAvatarComponent")
        if VehicleAvatarComponentRef and VehicleAvatarComponentRef.__inner_impl and not _G.VehicleAvatarSwitchHacked then
            VehicleAvatarComponentRef.__inner_impl.CheckCanPlaySkinSwitchEffect = function(self, curVehicleId, lastVehicleId) return true end
            _G.VehicleAvatarSwitchHacked = true
        end

        local LobbyVehicleRef = package.loaded["client.lobby_ue_object.Actor.LobbyVehicle"] or require("client.lobby_ue_object.Actor.LobbyVehicle")
        if LobbyVehicleRef and not _G.LobbyVehicleHacked then
            local preChangeVehicleAvatar = LobbyVehicleRef.PreChangeVehicleAvatar
            LobbyVehicleRef.PreChangeVehicleAvatar = function(self, InAvatarID, InAdvanceAvatarID)
                local vehicleSkinsListItem = _G.get_vehicle_skin_id(InAvatarID)
                if vehicleSkinsListItem and vehicleSkinsListItem ~= InAvatarID and vehicleSkinsListItem ~= 0 then
                    if not _G.skinIdCache[vehicleSkinsListItem] then
                        if _G.download_item then pcall(_G.download_item, vehicleSkinsListItem) end
                        _G.skinIdCache[vehicleSkinsListItem] = true
                    end
                    InAvatarID = vehicleSkinsListItem
                end
                local bIsDisabled7 = false
                if preChangeVehicleAvatar then bIsDisabled7 = preChangeVehicleAvatar(self, InAvatarID, InAdvanceAvatarID) end
                pcall(function()
                    self.ClientUsedAvatarID = InAvatarID
                    if self.PlayStartUpEffect then self:PlayStartUpEffect() end
                    if self.PlayAccelerateEffect then self:PlayAccelerateEffect() end
                end)
                return bIsDisabled7
            end
            _G.LobbyVehicleHacked = true
        end
    end)
end

-- ============================================================
-- [12] FORCE ENABLE KILL COUNTER UI
-- ============================================================

-- ============================================================
-- [13] BYPASS RESULT LOGGER → /sdcard/Download/results.json
-- ============================================================
-- ============================================================
-- [13] BYPASS RESULT LOGGER → /sdcard/Download/results.json
--     V2 ROBUST: multi-method write, multi-path, safe os
-- ============================================================

-- Force unique init per-file (biar tidak tabrakan dengan file lain)
if not _G.BypassResults or not _G.BypassResults.meta
   or _G.BypassResults.meta.file ~= "anticp.cpp" then
    _G.BypassResults = {
        meta = {
            mod = "UltimateEngine",
            version = "V11",
            file = "anticp.cpp",
            start_time = 0,
            start_time_str = "unknown",
        },
        bypasses = {},
        features = {},
        summary = {},
    }
end

-- [SAFE] os.time / os.date (kalau di-sandbox)
local function safe_time()
    local ok, t = pcall(function() return os.time() end)
    if ok and tonumber(t) then return tonumber(t) end
    return 0
end

local function safe_date(fmt)
    local ok, d = pcall(function() return os.date(fmt) end)
    if ok and type(d) == "string" then return d end
    return "unknown"
end

_G.BypassResults.meta.start_time = safe_time()
_G.BypassResults.meta.start_time_str = safe_date("%Y-%m-%d %H:%M:%S")

local function BypassLog(name, success, err_msg)
    _G.BypassResults.bypasses[name] = {
        name = name,
        status = success and "OK" or "FAILED",
        timestamp = safe_time(),
        time_str = safe_date("%H:%M:%S"),
        error = err_msg or nil,
    }
    print(string.format("[BypassLog] %-40s => %s%s",
        name, success and "OK" or "FAILED",
        err_msg and (" [" .. tostring(err_msg) .. "]") or ""))
end

local function RunBypassSafe(name, fn)
    if type(fn) ~= "function" then
        BypassLog(name, false, "function not found")
        return false
    end
    local ok, err = pcall(fn)
    BypassLog(name, ok, not ok and tostring(err) or nil)
    return ok
end

local function json_escape(s)
    if not s then return "" end
    s = tostring(s)
    s = s:gsub("\\", "\\\\"):gsub('"', '\\"'):gsub("\n", "\\n"):gsub("\r", "\\r"):gsub("\t", "\\t")
    return s
end

local function table_to_json(t, indent)
    indent = indent or ""
    local nextIndent = indent .. "  "
    local ty = type(t)
    if ty == "nil" then return "null" end
    if ty == "boolean" or ty == "number" then return tostring(t) end
    if ty == "string" then return '"' .. json_escape(t) .. '"' end
    if ty ~= "table" then return '"' .. json_escape(tostring(t)) .. '"' end

    local is_array, count = true, 0
    for k, _ in pairs(t) do
        count = count + 1
        if type(k) ~= "number" then is_array = false; break end
    end
    if count == 0 then return "[]" end

    local parts = {}
    if is_array then
        for _, v in ipairs(t) do table.insert(parts, nextIndent .. table_to_json(v, nextIndent)) end
        return "[\n" .. table.concat(parts, ",\n") .. "\n" .. indent .. "]"
    else
        for k, v in pairs(t) do
            table.insert(parts, nextIndent .. '"' .. json_escape(tostring(k)) .. '": ' .. table_to_json(v, nextIndent))
        end
        return "{\n" .. table.concat(parts, ",\n") .. "\n" .. indent .. "}"
    end
end

-- ============================================================
-- [WRITE FILE] Multi-method (io.open → File class → CGame)
-- ============================================================
local function write_file_robust(path, content)
    -- METHOD 1: io.open "w"
    local ok1, err1 = pcall(function()
        local f = io.open(path, "w")
        if not f then error("io.open nil") end
        f:write(content)
        f:close()
    end)
    if ok1 then return true, "io.open_w" end

    -- METHOD 2: io.open "wb"
    local ok2, err2 = pcall(function()
        local f = io.open(path, "wb")
        if not f then error("io.open wb nil") end
        f:write(content)
        f:close()
    end)
    if ok2 then return true, "io.open_wb" end

    -- METHOD 3: _G.File (kalau ada di env)
    if _G.File and _G.File.WriteAllText then
        local ok3 = pcall(function() _G.File.WriteAllText(path, content) end)
        if ok3 then return true, "File.WriteAllText" end
    end

    -- METHOD 4: CGame:SaveStringToFile
    if _G.CGame and _G.CGame.SaveStringToFile then
        local ok4 = pcall(function() CGame:SaveStringToFile(path, content) end)
        if ok4 then return true, "CGame:SaveStringToFile" end
    end

    -- METHOD 5: slua.saveFile (kadang ada)
    if _G.slua and _G.slua.saveFile then
        local ok5 = pcall(function() _G.slua.saveFile(path, content) end)
        if ok5 then return true, "slua.saveFile" end
    end

    return false, string.format("io1=[%s] io2=[%s]", tostring(err1), tostring(err2))
end

function _G.SaveBypassResults(extra_info)
    -- Update summary
    local total, ok_count, fail_count = 0, 0, 0
    for _, v in pairs(_G.BypassResults.bypasses) do
        total = total + 1
        if v.status == "OK" then ok_count = ok_count + 1 else fail_count = fail_count + 1 end
    end
    _G.BypassResults.summary = {
        total = total,
        success = ok_count,
        failed = fail_count,
        success_rate = total > 0 and string.format("%.1f%%", (ok_count / total) * 100) or "N/A",
    }
    _G.BypassResults.meta.end_time = safe_time()
    _G.BypassResults.meta.end_time_str = safe_date("%Y-%m-%d %H:%M:%S")
    _G.BypassResults.meta.uptime_sec = _G.BypassResults.meta.end_time - _G.BypassResults.meta.start_time

    if extra_info then
        for k, v in pairs(extra_info) do _G.BypassResults.meta[k] = v end
    end

    local json = table_to_json(_G.BypassResults, "")

    -- MULTI PATH FALLBACK (termasuk /data/local/tmp/ yang biasanya writable)
    local paths = {
        "/sdcard/Download/results.json",
        "/storage/emulated/0/Download/results.json",
        "/sdcard/results.json",
        "/storage/emulated/0/Android/data/com.pubg.krmobile/files/results.json",
        "/storage/emulated/0/Android/data/com.tencent.ig/files/results.json",
        "/storage/emulated/0/Android/data/com.vng.pubgmobile/files/results.json",
        "/storage/emulated/0/Android/data/com.rekoo.pubgm/files/results.json",
        "/data/local/tmp/results.json",
        "/sdcard/UE/results.json",
        "/sdcard/Android/data/results.json",
    }

    local saved, success_path, method_used = false, nil, nil
    for _, path in ipairs(paths) do
        print("[SaveBypassResults] Trying: " .. path)
        local ok, method_or_err = write_file_robust(path, json)
        if ok then
            print("[SaveBypassResults]   ✓ SUCCESS via " .. tostring(method_or_err) .. " → " .. path)
            saved = true
            success_path = path
            method_used = method_or_err
            -- Jangan break — tulis ke SEMUA path yang bisa (backup)
        else
            print("[SaveBypassResults]   ✗ FAILED → " .. path .. " : " .. tostring(method_or_err))
        end
    end

    if saved then
        print(string.format("[SaveBypassResults] ✓ SAVED (first=%s, method=%s)",
            tostring(success_path), tostring(method_used)))
    else
        print("[SaveBypassResults] ⚠️⚠️ SEMUA PATH GAGAL! Cek permission storage / root.")
        print("[SaveBypassResults] ⚠️ Total path dicoba: " .. #paths)
        -- Fallback emergency: print JSON ke log
        print("[SaveBypassResults] === JSON DUMP === " .. json .. " === END DUMP ===")
    end

    return saved
end

-- ============================================================
-- MASTER INITIALIZER
-- ============================================================
local function InitAllBypasses()
    print("[UltimateEngine] Starting all bypasses...")

    _G.BypassResults.features = {
        FPS_Unlock_165 = true,
        Timestamp_Until_2099 = true,
        Skin_Attachments_Loaded = _G.VIP_Attachments ~= nil,
        Skin_IDs_Loaded = _G.skinIdMappings ~= nil,
    }

    RunBypassSafe("InitializeAntiReport",              _G.InitializeAntiReport)
    RunBypassSafe("InitializeAntiCheatHooks",          _G.InitializeAntiCheatHooks)
    RunBypassSafe("InitializeGameplayBypass",          _G.InitializeGameplayBypass)
    RunBypassSafe("InitializeConnectionGuard",         _G.InitializeConnectionGuard)
    RunBypassSafe("DisableHiggsBoson",                 _G.DisableHiggsBoson)
    RunBypassSafe("InitializeLogBlocker",              _G.InitializeLogBlocker)
    RunBypassSafe("InitializeScannerBlocker",          _G.InitializeScannerBlocker)
    RunBypassSafe("InitializeReplayTelemetryBlocker",  _G.InitializeReplayTelemetryBlocker)
    RunBypassSafe("InitializeSkinBypass",              _G.InitializeSkinBypass)
    RunBypassSafe("InitializeSkinModSystem",           _G.InitializeSkinModSystem)
    RunBypassSafe("ForceEnableKillCounterUI",          _G.ForceEnableKillCounterUI)

    _G.BypassResults.features.ConnectionGuard_Initialized = _G.ConnectionGuardInitialized == true
    _G.BypassResults.features.GameplayCallbacks_Bypassed = _G.GameplayCallbacks and _G.GameplayCallbacks.IsBypassed == true
    _G.BypassResults.features.KCUI_Hacked = _G.KCUISystemHacked2 == true
    _G.BypassResults.features.KCLogic_Hacked = _G.KCLogicHacked2 == true
    _G.BypassResults.features.KillInfoCounter_Hacked = _G.KillInfoCounterHacked == true
    _G.BypassResults.features.SlotBase_Hacked = _G.SlotBaseHacked == true
    _G.BypassResults.features.LobbyBypass_Hacked = _G.LobbyBypassHacked == true
    _G.BypassResults.features.IconBalo_Hacked = _G.IconBaloHacked == true
    _G.BypassResults.features.VehicleEffect_Hacked = _G.VehicleEffectHacked == true
    _G.BypassResults.features.VehicleAvatarSwitch_Hacked = _G.VehicleAvatarSwitchHacked == true
    _G.BypassResults.features.LobbyVehicle_Hacked = _G.LobbyVehicleHacked == true

    _G.SaveBypassResults({
        game = "PUBGM",
        package = "com.pubg.krmobile",
        file_type = "anticp",
    })

    print("[UltimateEngine] ✓ Semua bypass selesai.")
end

-- ============================================================
-- RETRY & MULTI-TRIGGER (supaya pasti jalan)
-- ============================================================
local function safe_timer_call(delay, fn)
    local ok, ticker = pcall(require, "common.time_ticker")
    if ok and ticker and ticker.AddTimerOnce then
        pcall(function() ticker.AddTimerOnce(delay, fn) end)
        return true
    end
    return false
end

-- Trigger 1: via time_ticker (delay 0.5s)
local timer_ok = safe_timer_call(0.5, InitAllBypasses)

-- Trigger 2: kalau ticker gagal, panggil langsung
if not timer_ok then
    print("[UltimateEngine] time_ticker unavailable, calling InitAllBypasses immediately")
    pcall(InitAllBypasses)
end

-- Trigger 3: RETRY — kalau file belum kesave, coba lagi 5s & 10s
safe_timer_call(5.0, function()
    pcall(function()
        if _G.BypassResults and #(_G.BypassResults.bypasses or {}) == 0 then
            print("[UltimateEngine] RETRY: bypasses empty, re-init")
            pcall(InitAllBypasses)
        else
            print("[UltimateEngine] RETRY 5s: re-save results")
            if _G.SaveBypassResults then
                _G.SaveBypassResults({ retry = "5s" })
            end
        end
    end)
end)

safe_timer_call(10.0, function()
    pcall(function()
        if _G.SaveBypassResults then
            _G.SaveBypassResults({ retry = "10s" })
        end
    end)
end)

-- ============================================================
-- AUTO-SAVE 30 DETIK
-- ============================================================
do
    local ok, ticker = pcall(require, "common.time_ticker")
    if ok and ticker and ticker.AddTimerLoop then
        ticker.AddTimerLoop(0, function()
            pcall(function()
                if _G.BypassResults and _G.SaveBypassResults then
                    _G.BypassResults.features.ConnectionGuard_Initialized = _G.ConnectionGuardInitialized == true
                    _G.BypassResults.features.GameplayCallbacks_Bypassed = _G.GameplayCallbacks and _G.GameplayCallbacks.IsBypassed == true
                    _G.SaveBypassResults()
                end
            end)
        end, -1, 30.0)
    end
end

-- Manual API
_G.AntiCP_SaveResults = function() return _G.SaveBypassResults({ manual = true }) end
_G.AntiCP_GetResults   = function() return _G.BypassResults end
_G.AntiCP_DumpJSON     = function() return table_to_json(_G.BypassResults, "") end
print("[UltimateEngine] Logger ready. Manual trigger: _G.AntiCP_SaveResults()")
)Ultimate_LUA_END";