const char* myBypassProxy = R"Ultimate_LUA_END(

local function bangJoProxy(name, defaultReturn)
            return setmetatable({}, {
                __index = function(t, k)
                    return function(...)
                        print(string.env and string.format("[DUMMY_MOCK] Intercepted %s.%s", name, tostring(k)) or "")
                        return defaultReturn
                    end
                end,
                __call = function(t, ...)
                    return defaultReturn
                end
            })
        end

        local function ApplyBangJO()
            pcall(function()
                if Server then
                    Server.GetDSAppVersion = function() return "44.6.0.0" end
                end
            end)

            pcall(function()
                if Client then
                    Client.SetTssNetworkStatus = function() end
                    Client.GetIsPlayerUsingVPN = function() return 0 end
                    Client.GetAndroidSOVersion = function() return 32 end
                    Client.GetNativeVersion = function() return "44.6.0.0" end
                    Client.GetApplicationVersion = function() return "4.6.0.99999" end
                    --Client.GetAppVersion = function() return "4.5.0.5" end
                    Client.GetSrcVersion = function() return "" end
                    --Client.GetDevicePlatformName = function() return "Android" end
                    Client.MD5LuaString = function(str) return 0 end
                    Client.OnPakFileCRCCheck = function() return 0 end
                    Client.GetBlockCRC = function(filename, offset, size) return 0 end

                    setmetatable(Client, {
                        __index = function(t, k)
                            if type(k) == "string" and (k:find("Check") or k:find("Verify") or k:find("Protect") or k:find("Client")) then
                                return function(...) return true end
                            end
                            return rawget(t, k)
                        end
                    })
                end
                if _G.Tss or _G.TSSSystem then
                    _G.Tss = bangJoProxy("Tss", 0)
                end
                if _G.Higgs or _G.HiggsSDK then
                    _G.Higgs = bangJoProxy("Higgs", 0)
                end
            end)
        end


local function JandaBangJO()
    pcall(function()
        local gc_util = require("common.gc_util")
        local utility = require("common.utility")
        local DevicePlatformNameMacros = require("client.slua.config.ClientMacros.DevicePlatformNameMacros")
        local fakeDevices = {"SM-G9550", "Pixel 7 Pro", "iPhone 14 Pro", "Galaxy S23 Ultra", "Xiaomi 13"}
        math.randomseed(os.time())
        local randomFakeDevice = fakeDevices[math.random(#fakeDevices)]
        DevicePlatformNameMacros.GetDeviceName = function()
            return randomFakeDevice
        end

        local original_IsNeedClearUIPool = gc_util.IsNeedClearUIPool
        gc_util.IsNeedClearUIPool = function()
            local bDisableClearUIPool = HDmpveRemote.HDmpveRemoteConfigGetBool("DisableClearUIPool", true)
            if bDisableClearUIPool then
                if type(log_shipping_client) == "function" then
                end
                return false
            end
            local UScriptHelperClient = import("ScriptHelperClient")
            if UScriptHelperClient and type(UScriptHelperClient.GetObjectArrayNum) == "function" then
                local ObjectNum = UScriptHelperClient.GetObjectArrayNum()
                if GnMaxClearObjectNum <= 0 or ObjectNum > GnMaxClearObjectNum then
                    if type(log_shipping_client) == "function" then
                    end
                    return false
                end
            end
            local memoryStatus = Client.GetMemoryStats()
            local totalPhysicalMem = Client.GetMemorySize()
            local usedPhysical = memoryStatus.UsedPhysical / 1024.0 / 1024.0
            if Client.GetDevicePlatformName() == DevicePlatformNameMacros.Android then
                local threshold = (totalPhysicalMem * 0.15 + 0.85) * 1024
                if usedPhysical > threshold then
                    return false
                end
            elseif totalPhysicalMem <= 4 then
                local threshold = 500 + 200 * totalPhysicalMem
                local jandaaa = 32
                if Client.GetAndroidSOVersion() == jandaaa and totalPhysicalMem < 4 then
                    threshold = threshold - 100
                end
                if usedPhysical > threshold then
                    return false
                end
            else
                if usedPhysical > 900 + 100 * totalPhysicalMem then
                    return true
                end
            end
            return false
        end
        gc_util.IsNeedDropAvatarFeature = function(DropLevel)
            return false
        end
        gc_util.GCByMaxObjectOrMemory = function()
            return
        end
        gc_util.FullGC = function()
            return
        end
    end)
end

local function MasterClientBypass()
    pcall(function()
        --BYPASS LOGIC_LOGIN_BACKUP (IP & Storage)
        local backupPath = "client.logic.login.logic_login_backup"
        local logic_login_backup = package.loaded[backupPath] or require(backupPath)
        if logic_login_backup then
            logic_login_backup.PollingNextIp = function()
                return 0
            end
            logic_login_backup.SaveGame = function(param_name, value) return 0 end
            logic_login_backup.LoadGame = function(param_name) return nil end
        end
        --BYPASS LOGIC_TT_BAN (Region, VPN, Check)
        local banPath = "client.logic.login.logic_tt_ban"
        local logic_tt_ban = package.loaded[banPath] or require(banPath)
        if logic_tt_ban then
            logic_tt_ban.CheckIfCanCreateRole = function(self) return true end
            logic_tt_ban.NatvieClientCheckFlow = function(self, SkipNewPlayerCheck) return true end
            logic_tt_ban.WebClientCheckFlow = function(self, SkipNewPlayerCheck) return true end
            logic_tt_ban.BlockAndReturnLogin = function(self) end
            logic_tt_ban.GetTTBlockType = function(self) return self.BlockType.Disable end
            logic_tt_ban.IsVPNConnected = function(self) return 0 end
        end
        --BYPASS VERSION_UP_MODULE (Update, TSS, ResPak)
        local verPath = "client.logic.update_login.version_up_module"
        local version_up_module = package.loaded[verPath] or require(verPath)
        if version_up_module then
            version_up_module.CheckContinueUpdate = function(self) return false end
            version_up_module.IsInLoginForceUpdateProgress = function(self) return false end
            version_up_module.TemporarilySwitchToLoginScreen = function(self, tips) end
            version_up_module.StartGrayUpdate = function(self, callback)
                if callback ~= nil then callback() end
            end
            version_up_module.NeedSkipAppUpdatingInBlueHole = function(self) return true end
            version_up_module.NeedSkipGrayUpdatingInBlueHole = function(self) return true end
            version_up_module.IsShowUpdatePrompt = function(self) return false end
            version_up_module.InitializePuffer = function(self, useLobbyINTF) end
            version_up_module.GetTssVersion = function(self) return 0 end
            version_up_module.CheckFitLobbyResPakExist = function(self, paklist)
                local success, LogicPufferBundle = pcall(function()
                    return require("client.slua.logic.download.bundle.logic_puffer_bundle")
                end)
                if success and LogicPufferBundle then
                    LogicPufferBundle.bFitLobbyResExist = true
                end
            end
        end
    end)
end

local function RandomDeviceAndBanBypass()
    pcall(function()
        --BYPASS BAN_LOGIN_MODULE (Anti-Ban & Kickout)
        local banPath = "client.slua.logic.login.ban_login_module"
        local ban_login_module = package.loaded[banPath] or require(banPath)
        if ban_login_module then
            ban_login_module.ShowIDIPBanTips = function(self, banInfo, banTime, uid)
            end
            ban_login_module.on_kickout = function(self, msg, banInfo, banTime, localizeResID, op_type, sDeviceName, ext_info, login_channel, info)
            end
        end
        --RANDOM DEVICE INFO (Device Spoofing)
        local deviceOsPath = "client.logic.data.data_device_os"
        local DeviceOSInfo = package.loaded[deviceOsPath] or require(deviceOsPath)
        if DeviceOSInfo and DeviceOSInfo.getDeviceOSInfo then
            local original_getDeviceInfo = DeviceOSInfo.getDeviceOSInfo
            DeviceOSInfo.getDeviceOSInfo = function(...)
                local result = original_getDeviceInfo(...)
                if DeviceOSInfo.InfoList then
                    local randomSuffix = math.random(10000, 99999)
                    if type(DeviceOSInfo.InfoList) == "table" then
                        DeviceOSInfo.InfoList.device_id = "rand_dev_" .. randomSuffix
                        DeviceOSInfo.InfoList.imei = "fake_imei_" .. randomSuffix
                        DeviceOSInfo.InfoList.mac = "02:00:00:" .. string.format("%02x:%02x:%02x", math.random(0,255), math.random(0,255), math.random(0,255))
                        DeviceOSInfo.InfoList.device_name = "CustomDevice_" .. randomSuffix
                    end
                end
                return result
            end
        end
    end)
end

local function ClientReportBypass()
    pcall(function()
        local reportPath = "client.slua.data.BasicData.BasicDataReport"
        local reportModule = package.loaded[reportPath] or require(reportPath)
        if reportModule then
            reportModule._IsCanReport = function(self, ReportType, Error_Str)
                print("[Bypass] Pelaporan data klien dicegah untuk Tipe:", ReportType)
                return false
            end
            reportModule.ReportImmediate = function(self, ReportType, Error_Str) end
            reportModule.ReportDelay = function(self, ReportType, Error_Str) end
            print("[Bypass] Modul BasicDataClientReport!")
        else
            print("[Bypass] Gagal menemukan modul BasicDataClientReport.")
        end
    end)
end


local function lolol()
    pcall(function()
        local loginModulePath = "client.slua.logic.login.login_module"
        local login_module = package.loaded[loginModulePath] or require(loginModulePath)
        if login_module then
            if type(login_module.DefineAndResetData) == "function" then
                pcall(function()
                    login_module:DefineAndResetData()
                end)
            end
            pcall(function()
                local AOSSHOPMacros = require("client.slua.config.ClientMacros.AOSSHOPMacros")
                if AOSSHOPMacros then
                    AOS2Index = {}
                end
            end)

            login_module.EncryptionManagerPre = function() return 0 end
            login_module.FromUpdateToLogin = function() return 0 end
            login_module.SetupFilenameHideKeywords = function() return 0 end
            login_module.PakMonitorStart = function() return 0 end
            login_module.reqLoginLobby = function() return 0 end

            -- BYPASS THIRDPART / SDK LOGIN (Mematikan fungsi login pihak ketiga)
            login_module.SdkLogin = function(self, loginType)
                log_warning(bWriteLog and "login_module.SdkLogin bypassed.")
                return 0
            end
            login_module.DelayInitThirdPartSDK = function(self)
                log(bWriteLog and "[Bypass] DelayInitThirdPartSDK disabled.")
                return 0
            end
            login_module.IsAvailableChannel = function(self, channel)
                return false
            end

            login_module.SetIgnoreResourceVersion = function() return 0 end
            login_module.SetsIgnoreAppVersion = function() return 0 end
            login_module.OnGetEnableCDNGetVersion = function() return 0 end
            login_module.ReportLocalResourcePakGEM = function() return 0 end
            login_module.ReportSysInfoToGEM = function() return 0 end

            login_module.ConnectToGate = function(self, addrArray, addrID, areaID, addrName)
                local logic_cost_collector = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_cost_collector)
                logic_cost_collector:MarkEventEnd(logic_cost_collector.EVENT_KEYS.LOGIN)
                logic_cost_collector:MarkEventEnd(logic_cost_collector.EVENT_KEYS.CHOOSE_SERVER)
                logic_cost_collector:MarkEventStart(logic_cost_collector.EVENT_KEYS.CONNECT_SERVER)
                logic_cost_collector:MarkIsolatedEventStart(logic_cost_collector.ISOLATED_EVENT_NAMES.WaitConnectToGate)
                FuncUtil.AddCrashContextMainFlow("61")
                Client.TriggerLoginCrashTest(0)

                if Tss then
                    Tss.TssHostInfo = 0
                    Tss.TssCDNHostInfo = 0
                    Tss.TssBuildInIpInfo = 0
                    Tss.SendSkdData_LuaState = function() return 0 end
                    Tss.SendEigeninfoData_LuaState = function() return 0 end
                    Tss.SaveSendEigeninfoCode_LuaState = function() return 0 end
                    Tss.OnRecvData_LuaState = function() return 0 end
                    Tss.GetUserTag4Lua_LuaState = function() return 0 end
                    Tss.GetDeviceFeature_LuaState = function() return 0 end
                    Tss.EigenArrayObfuscationVerify_LuaState = function() return 0 end
                    Tss.InvokeSDKIoctl = function() return 0 end
                end
                if addrArray then
                    self.lastAddrArray = addrArray
                else
                    addrArray = self.lastAddrArray
                end
                if addrID then
                    self.lastAddrID = addrID
                else
                    addrID = self.lastAddrID
                end
                if areaID then
                    self.lastAreaID = areaID
                else
                    areaID = self.lastAreaID
                end

                pcall(function()
                    local login_protect_utils = require("client.slua.logic.login.login_protect_utils")
                    if login_protect_utils then
                        login_protect_utils.GetLoginCd = function() return 0 end
                        login_protect_utils.CheckCanLogin = function() return true, 0 end
                        login_protect_utils.LoadLoginInfoFile = function() end
                        login_protect_utils.SaveLoginInfoFile = function() end
                        login_protect_utils.RecordLoginFailTime = function() end
                        login_protect_utils.RecordLoginSucTime = function() end
                    end
                end)

                pcall(function()
                    local PlayerPrefsSystem = require("client.logic.LogicPlayerPrefs.playerprefs")
                    if PlayerPrefsSystem then
                        PlayerPrefsSystem.SaveTableToFile_N({}, PlayerPrefsSystem.ePlayerPrefsType.eLoginData)
                        PlayerPrefsSystem.SaveTableToFile_N({}, PlayerPrefsSystem.ePlayerPrefsType.eLoginHDmpveErr)
                        PlayerPrefsSystem.SaveTableToFile_N({}, PlayerPrefsSystem.ePlayerPrefsType.eLastLoginChannel)
                        PlayerPrefsSystem.SaveTableToFile_N({}, PlayerPrefsSystem.ePlayerPrefsType.eScanLogin)
                        PlayerPrefsSystem.SaveTableToFile_N({}, PlayerPrefsSystem.ePlayerPrefsType.eScanLoginOld)
                    end
                end)

                pcall(function()
                    local SettingAccount = require("client.logic.setting.logic_setting_account")
                    if SettingAccount and SettingAccount.ClientLogout then
                        SettingAccount.ClientLogout()
                    end
                end)

                local NetManager = require("client.network.comm.NetManager")
                NetManager.Init()
                local logic_manager = require("client.logic.common.logic_manager")
                logic_manager.Init()

                local _addrArray
                local _addrID = 0
                local _serverName = "正式服"
                local logic_login_server_utils = require("client.logic.update_login.logic_login_server_utils")
                if globalConfig.isSupervision then
                    self.serverInfo = logic_login_server_utils.GetServerInfoByTypeAndRegion("SupervisionServer", PublishRegionMacros.GLOBAL)
                    _addrArray = self.serverInfo.addr
                elseif globalConfig.IsDirectConnect() == false then
                    _addrArray = addrArray
                    _addrID = addrID
                else
                    local PublishAreaMgr = import("PublishAreaMgr")
                    local area = PublishAreaMgr.GetArea()
                    if area == "DEFAULT" then
                        self.serverInfo = logic_login_server_utils.GetServerInfoByTypeAndRegion("OfficialServer", strRegion)
                    else
                        self.serverInfo = logic_login_server_utils.GetServerInfoByTypeAndRegion("OfficialServer", strRegion, area)
                    end
                    if self.serverInfo ~= nil then
                        _addrArray = self.serverInfo.addr
                    end
                end

                if _addrArray and 0 < #_addrArray then
                    local utility = require("common.utility")
                    local logic_login_backup = require("client.logic.login.logic_login_backup")
                    xpcall(logic_login_backup.InitBackUpIPs, utility.ErrorMessageHandler, _addrArray)
                    self.loginLobbyInfo.AddrID = _addrID
                    self:connectLobby()
                end
            end

            login_module.reqLoginLobby = function(self, isRelogin, reportId)
                local DeviceOSInfo = require("client.logic.data.data_device_os")
                if not self.loginLobbyInfo then return end

                local IMSDKHelper = import("IMSDKHelper")
                local IMSDKHelperInstance = IMSDKHelper.GetInstance()
                local openId = IMSDKHelperInstance:getOpenID()
                self:UpdateAccountDataWithLogin(isRelogin, openId)

                local ext_info = {
                    relogin = isRelogin,
                    isTimeOutRelogin = NetUtil.bIsTimeOutReconnect,
                    ob_version = GetWindowOBState(),
                    reportId = reportId,
                    bCrash = false,
                    is_small_pkg = false,
                    loginAccountData = self.loginAccountData
                }

                NetUtil.StartCheckLoginRsp()
                self.bIsRelogin = isRelogin
                self:RemoveLoginTimer()
                self.loginTimer = self:AddTimerOnce(20, function()
                    self:LoginTimeOut()
                end)

                local LoginHandler = require("client.network.Protocol.LoginHandler")
                LoginHandler.send_login(Client.GetAppVersion(), DeviceOSInfo.InfoList, 0, ext_info, 0, 0, 0, "", "", "", 0, 0, "", "", 0, 1, 0, {}, "", {})
                self.bRecvSyncBaseInfo = false
                self.bHasSendLogin = true
            end
        end

        local settingAccountPath = "client.logic.setting.logic_setting_account"
        local SettingAccount = package.loaded[settingAccountPath] or require(settingAccountPath)
        if SettingAccount then
            local originalLogout = SettingAccount.Logout
            SettingAccount.Logout = function(...)
                pcall(function()
                    if SettingAccount.DeleteQRCodeLogin then
                        SettingAccount.DeleteQRCodeLogin()
                    end
                end)

                pcall(function()
                    local PlayerPrefsSystem = require("client.logic.LogicPlayerPrefs.playerprefs")
                    if PlayerPrefsSystem then
                        PlayerPrefsSystem.SaveTableToFile_N({}, PlayerPrefsSystem.ePlayerPrefsType.eScanLogin)
                        PlayerPrefsSystem.SaveTableToFile_N({}, PlayerPrefsSystem.ePlayerPrefsType.eScanLoginOld)
                        PlayerPrefsSystem.SaveTableToFile_N({}, PlayerPrefsSystem.ePlayerPrefsType.eAccountSafeStealModelFlag)
                    end
                end)

                if originalLogout then
                    return originalLogout(...)
                end
            end

            local originalClientLogout = SettingAccount.ClientLogout
            SettingAccount.ClientLogout = function(...)
                pcall(function()
                    local WinLoginSystem = require("client.logic.login.logic_winlogin")
                    if WinLoginSystem and WinLoginSystem.ClearMailLoginCache then
                        WinLoginSystem.ClearMailLoginCache()
                    end
                end)

                if originalClientLogout then
                    return originalClientLogout(...)
                else
                    Client.Logout(NetInterface)
                end
            end

            pcall(function()
                SettingAccount.DeleteQRCodeLogin()
            end)
        end
    end)
end

local function LoginProtectBypass()
    pcall(function()
        local loginUtilsPath = "client.slua.logic.login.login_protect_utils"
        local LoginProtectUtils = package.loaded[loginUtilsPath] or require(loginUtilsPath)
        if LoginProtectUtils then
            LoginProtectUtils.GetLoginCd = function(times)
                return 0
            end
            LoginProtectUtils.CheckCanLogin = function()
                return true, 0
            end
            LoginProtectUtils.LoadLoginInfoFile = function() end
            LoginProtectUtils.SaveLoginInfoFile = function() end
            LoginProtectUtils.RecordLoginFailTime = function() end
            LoginProtectUtils.RecordLoginSucTime = function() end
            print("[Bypass] Modul LoginProtectUtils!")
        else
            print("[Bypass] Gagal menemukan modul LoginProtectUtils.")
        end
    end)
end


local function ClientReportBypass()
    local reportPath = "client.slua.data.BasicData.BasicDataReport"

    -- Cek dulu apakah modulnya sudah ada di package.loaded
    local reportModule = package.loaded[reportPath]

    if not reportModule then
        log("[Bypass] Modul BasicDataReport belum ada di package.loaded, mencoba require...")
        -- Bungkus require dengan pcall terpisah biar error-nya kelihatan
        local success, err = pcall(function()
            return require(reportPath)
        end)
        if success then
            reportModule = err
        else
            log("[Bypass ERROR] Gagal require modul:", tostring(err))
            return
        end
    end

    if reportModule then
        -- Hook ReportImmediate agar menghentikan eksekusi OnImmediateReqMsg
        reportModule.ReportImmediate = function(self, ...)
            log("[Bypass] ReportImmediate dicegah.")
            return
        end

        -- Hook ReportDelay agar tidak memicu _SendReqMsg
        reportModule.ReportDelay = function(self, ...)
            log("[Bypass] ReportDelay dicegah.")
            return nil
        end

        -- Hook _SendReqMsg karena fungsi ini nyata dipanggil oleh ReportDelay
        if reportModule._SendReqMsg then
            reportModule._SendReqMsg = function(self, ...)
                log("[Bypass] _SendReqMsg dicegah total.")
                return
            end
        end

        -- Opsional: Hook _BatchReqMsg untuk mencegah pengiriman batch saat login
        if reportModule._BatchReqMsg then
            reportModule._BatchReqMsg = function(self)
                log("[Bypass] _BatchReqMsg dicegah.")
                return
            end
        end

        log("[Bypass] Berhasil mengaitkan (hook) modul BasicDataReport!")
    else
        log("[Bypass] Gagal menemukan modul BasicDataReport (nil).")
    end
end

local function BatchClassBypass()
    local batchPath = "client.slua.data.BasicData.BaseClass.BasicDataBatchClass"

    -- Cek dulu di package.loaded
    local batchModule = package.loaded[batchPath]

    if not batchModule then
        log("[Bypass] Modul BasicDataBatchClass belum ada di package.loaded, mencoba require...")
        local success, err = pcall(function()
            return require(batchPath)
        end)
        if success then
            batchModule = err
        else
            log("[Bypass ERROR] Gagal require BasicDataBatchClass:", tostring(err))
            return
        end
    end

    if batchModule then
        -- 1. Hook _SendReqMsg untuk menghentikan proses pengiriman request batch/single
        batchModule._SendReqMsg = function(self, key, ...)
            log("[Bypass] _SendReqMsg dicegah untuk key:", tostring(key))
            return
        end

        -- 2. Hook _BatchProcessing agar data tidak pernah masuk ke antrean timer
        batchModule._BatchProcessing = function(self, key, ...)
            log("[Bypass] _BatchProcessing diblokir untuk key:", tostring(key))
            return
        end

        -- 3. Hook _BatchReqMsg untuk memastikan tidak ada batch request yang dikirim ke server
        batchModule._BatchReqMsg = function(self)
            log("[Bypass] _BatchReqMsg di-bypass, timer dibersihkan.")
            if self._RemoveTimer then self:_RemoveTimer() end
            self._batchReqKeyTable = {}
            self._batchReqKeyTableCount = 0
        end

        log("[Bypass] Berhasil mengaitkan (hook) modul BasicDataBatchClass!")
    else
        log("[Bypass] Gagal menemukan modul BasicDataBatchClass (nil).")
    end
end



local function GokubaBypass()
            pcall(function()
                local Gokuba = package.loaded["GameLua.Mod.BaseMod.Client.Security.Gokuba"]
                if Gokuba then
                    Gokuba.ForwardFeature = function() return {0,0,0,0,0} end
                    Gokuba.InitGokubaLogic = function() end
                    if Gokuba.TimerHandle then
                        local time_ticker = require("common.time_ticker")
                        time_ticker.RemoveTimer(Gokuba.TimerHandle)
                        Gokuba.TimerHandle = nil
                    end
                    for k, v in pairs(Gokuba) do
                        if type(v) == "function" and (
                            k:find("Init") or k:find("Start") or k:find("Check") or
                            k:find("Scan") or k:find("Report") or k:find("Forward") or
                            k:find("Feature") or k:find("Detect") or k:find("Collect") or
                            k:find("Send") or k:find("Upload") or k:find("Verify") or
                            k:find("Analyze") or k:find("Process") or k:find("Handle")
                        ) then
                            Gokuba[k] = function() end
                        end
                    end
                end
                if _G.GokubaLogic then
                    _G.GokubaLogic.ForwardFeature = function() end
                    _G.GokubaLogic.InitGokubaLogic = function() end
                end
            end)
        end

local function GokubaBypassRoot()
    pcall(function()

        local possible_names = {
            "GameLua.Mod.BaseMod.Client.Security.Gokuba",
            "GameLua.Mod.BaseMod.Client.Security.GokubaLogic",
            "GokubaLogic"
        }

        local Gokuba = nil
        for _, name in ipairs(possible_names) do
            if package.loaded[name] then
                Gokuba = package.loaded[name]
                break
            end
        end


        if not Gokuba and _G.GokubaLogic then
            Gokuba = _G.GokubaLogic
        end


        if EventSystem and EventSystem.unregistEvent then
            pcall(function()
                EventSystem:unregistEvent(EVENTTYPE_INGAME, EVENTID_INGAME_CONTROLLER_BEGINPLAY, GokubaLogic and GokubaLogic.OnControllerBeginPlay)
            end)
        end

        if Gokuba then

            if Gokuba.TimerHandle then
                local success, time_ticker = pcall(require, "common.time_ticker")
                if success and time_ticker and time_ticker.RemoveTimer then
                    time_ticker.RemoveTimer(Gokuba.TimerHandle)
                end
                Gokuba.TimerHandle = nil
            end


            Gokuba.ForwardFeature = function()
                local safeResult = {
                    [1] = 0, -- Root: False
                    [2] = 0, -- Malware: False
                    [3] = 0, -- Cdn: False
                    [4] = 0, -- CS: False
                    [5] = 0  -- Permission: False
                }
                if NetUtil and NetUtil.SendPkg then
                    NetUtil.SendPkg("battle_client_sync_allstar_auth_check_result_req", safeResult)
                end
            end


            for k, v in pairs(Gokuba) do
                if type(v) == "function" and k ~= "ForwardFeature" then
                    Gokuba[k] = function(...)
                        return true
                    end
                end
            end
        end


        if _G.GokubaLogic then
            _G.GokubaLogic.ForwardFeature = function() end
            _G.GokubaLogic.InitGokubaLogic = function() end
            _G.GokubaLogic.OnControllerBeginPlay = function() end
            _G.GokubaLogic.TimerHandle = nil
        end


        for _, name in ipairs(possible_names) do
            package.preload[name] = function()
                return Gokuba or {}
            end
        end

        print("[Bypass] Gokuba bypass fully applied!")
    end)
end


-- Fungsi helper untuk mengosongkan fungsi-fungsi dalam modul
local function disableModule(path, funcNames)
    pcall(function()
        local mod = package.loaded[path] or require(path)
        if mod then
            for _, name in ipairs(funcNames) do
                mod[name] = function() return end
            end
        end
    end)
end

local function ProtectBypassJO()
    -- 1. BasicDataReport
    disableModule("client.slua.data.BasicData.BaseClass.BasicDataReport", {
        "ReportImmediate", "ReportDelay", "OnMergeReqMsg",
        "OnImmediateReqMsg", "OnSendBatchReqMsg", "_BatchReqMsg", "OnLogin"
    })

    -- 2. BasicDataBatchClass
    disableModule("client.slua.data.BasicData.BaseClass.BasicDataBatchClass", {
        "DefineAndResetData", "OnSendBatchReqMsg", "OnMergeReqMsg", "GetKeyMapInfo",
        "BatchGetOrReqData", "AddBatchGetCache", "OnHandleBatchMsgDataAndCallback",
        "OnHandleBatchMsgCallback", "GetCacheDataStateByList", "_SendReqMsg",
        "_BatchProcessing", "_BatchReqMsg"
    })

    -- 3. BasicDataBaseClass
    disableModule("client.slua.data.BasicData.BaseClass.BasicDataBaseClass", {
        "DefineAndResetData", "OnLogOut", "OnSendReqMsg", "OnPostSwitchGameStatus",
        "GetCacheData", "GetOrReqData", "OnHandleMsgDataAndCallback", "SetCacheMaxCount",
        "UpdateCacheKeyList", "CheckIsRemoveCache", "_SetDataCache", "_ReqData",
        "_CheckInWaiting", "_SetWaiting", "_SetCallback", "_ClearCallbackAndWaiting",
        "_SendReqMsg", "_GetCacheDataState"
    })

    -- 4. BasicDataTLogReport
    disableModule("client.slua.data.BasicData.BasicDataTLogReport", {
        "OnSendBatchReqMsg", "OnImmediateReqMsg", "OnMergeReqMsg",
        "send_report_event_duration_log", "_GetParamData"
    })
end

local function ProtectBypassDSJO()
    -- 1. DSCreditTLogSubsystem
    disableModule("GameLua.Mod.BaseMod.DS.Security.DSCreditTLogSubsystem", {
        "OnInit", "_OnPlayerSettlementStart", "_OnMaliciousTeammateDamage", "_GetCurrentTimeSeconds",
        "_HasFightingGameStateHappened", "_HasFinishedGameStateHappened", "_IsDuringFightingGameState",
        "_OnGameModeStateChange", "_OnPlayerJoin", "_ListenPlayerLostOrReconnectDelegate",
        "_HandlePlayerLostOrReconnect", "_HandleTeammateGrenadeDamage", "_MonitorPlayerInactivity",
        "_HandleTeammateMaliciousCarryBack", "_HandleExitTeamBeforeBoarding", "_HandleExitMatchDuringFighting",
        "_HasHealthyOnlineTeammate", "_IsPlayerHealthStatusHealthy", "_HasDisconnectedTeammate",
        "_GiveTeammateExemption", "_GetTeammateUIDList", "_HandleTeammateExplodeVehicle",
        "_GetPlayerUIDByPlayerKey", "_GetPlayerKeyByPlayerUID", "_RecordTLogForTeammateDamage",
        "_CreateBattleResultTLogForNegativePlayer", "_ConvertTeammateDamageTLogType", "_IsHealthStatusKnockDown",
        "_IsHealthStatusKilled", "_IsHealthStatusHealthy", "_ReportTLogOnGameModeFinished",
        "_IsBattleRoyaleGameMode", "_IsTeamDeathMatchGameMode", "_GetTableSize",
        "_GetTeammatePlayerStatesByPlayerKey", "_OnPlayerExitBattleInitiatively", "_HandleInitiativelyExitTeamBeforeBoarding",
        "_CreateBasicTLogTableForPlayer", "_PrintTLogBasicInfo", "_SendInitiativelyExitTeamBeforeBoardingTLog",
        "_IsGameModeEnabledForTeammateDamage", "_IsGameModeEnabledForExitTeamBeforeBoarding",
        "_IsGameModeEnabledForExitMatchDuringFighting", "_TellOtherTeammateExitTeamBeforeBoarding",
        "_AddExitTeamBeforeBoardingTeammates2PlayerBattleResult", "_AddBeHurtByTeammate2PlayerBattleResult",
        "_IsTeamDeathMatchRanking", "_HandlePlayerExitInPlane", "_AddExitInPlaneWithTeammateExitResult"
    })

    -- 2. DSGlueHiaSystem
    disableModule("GameLua.Mod.BaseMod.DS.Security.DSGlueHiaSystem", {
        "OverrideTriggerRealtimeVerify", "PostInitSystems", "PostChangeLastFrameFightingState",
        "GetTowerLocationArray", "GetReviveEndTime"
    })

    -- 3. DSMaliciousTeammateDetectionSubsystem
    disableModule("GameLua.Mod.BaseMod.DS.Security.DSMaliciousTeammateDetectionSubsystem", {
        "OnMaliciousTeammateCarryBackDetected", "OnInit", "_OnNearDeathOrRescued", "_OnCharacterDied",
        "_HandleTeammateDirectDamage", "_HasFightingGameStateHappened", "_IsDuringFightingGameState",
        "_OnGameModeStateChange", "_IsHealthStatusKilled", "_IsTeammateExceptSelf",
        "_RecordJustifiableDefense", "IsJustifiableDefense"
    })

    -- 4. DSPVSSubsystem
    disableModule("GameLua.Mod.BaseMod.DS.Security.DSPVSSubsystem", {
        "OnInit", "_StartRefreshGameModeModTypeTimer", "_RefreshGameModeModType", "EditorTriggerCoronaLabVerify"
    })

    -- 5. DSQuickReportMaliciousTeammate
    disableModule("GameLua.Mod.BaseMod.DS.Security.DSQuickReportMaliciousTeammate", {
        "OnMaliciousTeammateDamage", "_HandleMaliciousCarryBack", "_HandleGrenadeDamage",
        "_HandleExplodeVehicle", "_ForbidTeammatePickup", "_SendVictimAndPerpetratorTips",
        "_SendPerpetratorWarningTips", "_SendVictimQuickReportTips", "_IsTeamDeathMatchGameMode", "_IsCreativeGameMode"
    })

    -- 6. DSReportPlayerSubsystem
    disableModule("GameLua.Mod.BaseMod.DS.Security.DSReportPlayerSubsystem", {
        "OnInit", "_OnNearDeathOrRescued", "_OnPlayerSettlementStart", "_OnTeammateDamage",
        "_AddMLKillerUIDToBattleResult", "_AddFatalDamagerMapToBattleResult", "_AddKnockDownerToBattleResult",
        "_AddKillerToBattleResult", "_FindCacheByUID", "_GetFatalDamagerMap",
        "_AssignTeammateInTeamIndex", "_IsHealthStatusKilled", "_RecordTeammateMurderer",
        "_AddTeammateMurderToBattleResult", "_IsBattleResultTableValid", "_SaveHistoricalTeammateInfo",
        "_RecordFatalDamager", "_OnCharacterDied", "_OnPlayerReconnect", "_SyncFatalDamagerMap",
        "_AddGameModeTypeToBattleResult", "_UpdateMLAIUID", "_AddEnemyMapToBattleResult", "_OnNoNetStartUpDoor"
    })

    -- 7. DSSecurityNotifySystem
    disableModule("GameLua.Mod.BaseMod.DS.Security.DSSecurityNotifySystem", {
        "Initialize", "Notify", "SaveInfo", "PlayerHasLogin"
    })

    -- 8. DSSecurityTLogSubsystem
    disableModule("GameLua.Mod.BaseMod.DS.Security.DSSecurityTLogSubsystem", {
        "OnInit", "_OnReportServerJumpFlow", "_InitWhenEditor", "_OnDevAlert"
    })

    -- 9. KillFrequencyLimiter
    disableModule("GameLua.Mod.BaseMod.DS.Security.KillFrequencyLimiter", {
        "OverrideIsEnableRunning", "OverrideIsGeneralShooting"
    })

    -- 10. DSHawkEyePatrolSubsystem
    disableModule("GameLua.Mod.BaseMod.DS.Security.HawkEyeSpectate.DSHawkEyePatrolSubsystem", {
        "OnInit", "_OnCharacterDied", "_OnWatchPlayerExit", "_OnHawkReport",
        "_OnHawkImprison", "_OnPlayerRespawn", "_OnPlayerReconnect", "_OnSyncInspectorBroadcastCount",
        "_GetPlayerControllerByPlayerKey", "CheckPunishPlayer", "CheckInspectorBroadcast", "DoInspectorBroadcast",
        "ImprisonPlayer", "MarkSuspiciousPlayer", "_ReportCharacterDied", "IsExitedPlayerWantNextPatrol"
    })

    -- 11. CNearbyButNoFireSystem
    disableModule("GameLua.Mod.BaseMod.DS.Security.IllegalTeamUp.CNearbyButNoFireSystem", {
        "IsCheckPass1", "IsCheckPass2", "IsCheckPass5", "IsCheckPass6",
        "IsCheckPass7", "IsCheckPass8", "IsCheckPass11", "_IsPlayerSafeCallbackCheckPass"
    })
end

local function CrashKitBypassJO()
    disableModule("client.slua.logic.report.ReportPlatformCrashKit", {
        "Init", "ReInit", "IsWhite", "IsInCD", "IsCanReport", "Send",
        "SwitchLuaErrorTrace", "ForceSend", "_ConformSend", "SetXpcallLimit",
        "GetOpenBattleTrace", "AddServerTimeToCrashContext"
    })
end



local function Memek_JO()
    local SGC = "Server.GameplayCallbacks" or _G.GameplayCallbacks
    disableModule(SGC, {
        "GetModName", "LoadSettlementModule", "OnPostLoadMap", "OnDSPlayerStateChanged", "OnCharacterStateChanged", "OnGameModeStateChanged", "OnPlayerNetConnectionClosed", "OnPlayerActorChannelError", "OnPlayerSpectateException", "OnPlayerRPCValidateFailed", "OnShutdownAfterError", "RepListMismatchDetectTrigger", "OnPlayerDestroyed", "SendClientStats", "SendServerAvgTickDelta", "SendGameOver", "ReportMatchRoomData", "GetGeneralTLogData", "SendPlayerBattleResult", "GetPlayerBattleResultData", "GetRealPlayerCountByUID", "GetPlayerBattleResultRecord", "GetTeammateBattleResultRecord", "GetMergedPlayerBattleResult", "RecordPlayerBattleResult", "UploadLootsCache", "SubtractDroppedItemCount", "SendTeamBattleResult", "SendPlayerBattleResultToObserver", "SendTeamBattleResultToObserver", "SendDeathMatchBattleResult", "SendDeathMatchPlayerEscapeBattleResult", "SendDeathMatchPlayerDeathRoundData", "SendInfectionBattleResult", "SendInfectionPlayerEscapeBattleResult", "SendInfectionRoundTlogData", "SendVehicleBattleResult", "SendVehiclePlayerEscapeBattleResult", "SendZNQBattleResult", "SendGameStopJoin", "SendGameStart", "SendHeartBeat", "EnterWatchChain", "SendPlayerUseItem", "ReportIDCardProduceFlow", "ReportIDCardPickUpFlow", "ReportIDCardDestroyFlow", "ReportRevivalFlow", "ReportGameStartFlow", "ReportJumpFlow", "ReportCircleFlow", "ReportDSCircleFlow", "ReportGameEndFlow", "ReportAimFlow", "ReportEquipmentFlow", "ReportAttackFlow", "ReportSecAttackFlow", "ReportHurtFlow", "ReportCommonInfo", "ReportFeedback", "ReportPlayerBehavior", "ReportPlayerMoveRoute", "ReportPlayerPosition", "ReportForbitPick", "ReportTeammatHurt", "ReportFireArms", "ReportVerifyInfoFlow", "ReportGameSetting", "ReportGameSettingNew", "ReportAntsVoiceTeamCreate", "ReportAntsVoiceTeamQuit", "SendPlayerSpectatingLog", "ReportSecTgameMovingFlow", "GetPicUrlByOpenId", "SendTssSdkAntiDataToLobby", "SendDSErrorLogToLobbyOnece", "SendDSErrorLogToLobby", "SendDSHawkEyePatrolLogToLobby", "ReportMisKillByTeammate", "ReportMrpcsFlow", "ReportVehicleMoveFlow", "ReportHeavyWeaponBoxSpawnFlow", "ReportHeavyWeaponBoxActivationFlow", "ReportHeavyWeaponBoxOpenPlayerFlow", "ReportHeavyWeaponBoxItemFlow", "ReportAIStrategyInfo", "ReportDailyTaskInfo", "SendAIDeliveryInfo", "SendSocialIslandPlayerResult", "ReportPlayerIP", "ReportPlayerFramePingRecord", "OnDSConnectionSaturated", "ReportDSNetSaturation", "ReportNetContinuousSaturate", "ReportDSNetRate", "ReportParachuteData", "SendSecTLog", "SendDataMiningTLog", "SendActivityTLog", "ReportLightweightStat", "SetWatchPlayerExitFromGameServer", "IsWatchPlayerExitFromGameServer", "GetWeaponReport", "GetOneWeaponReport", "GetPlayerKillerFlow", "MainCityGenReplayDone", "MainCityLoadReplayDone", "ReqDSSwitchMainCity", "ReportPromotionAchieve"
    })
end


local function ClientEntryBypass()
    pcall(function()
        --lolol()
        --LoginProtectBypass()
        ApplyBangJO() --strlen on + app version on jolua2
        --JandaBangJO()
        --RandomeviceAndBanBypass()
        ClientReportBypass()
        BatchClassBypass()
        PatchSecurityNotify()
        GokubaBypass()
        GokubaBypassRoot()
        ProtectBypassJO()
        ProtectBypassDSJO()
        CrashKitBypassJO()
        Memek_JO()

        if slua_GameFrontendHUD and slua_GameFrontendHUD.OnFileModifiedDelegate then
            slua_GameFrontendHUD.OnFileModifiedDelegate:Clear()
        end
        if HDmpveRemote and HDmpveRemote.HDmpveRemoteConfigSetInt then
            HDmpveRemote.HDmpveRemoteConfigSetInt("EnableFileModifiedProtectMode", 0)
        end
        if NetManager then
            NetManager.ProcRespondMsg = function() end
            NetManager.isLogMsgAfterLogin = false
            NetManager.logMsgMap = {}
        end
        if EventSystem then
            local oldPost = EventSystem.postEvent
            EventSystem.postEvent = function(eventType, eventID, ...)
                if eventID and type(eventID) == "string" then
                    local blocked = {"SECURITY", "CHEAT", "BAN", "REPORT", "FLAG", "VIOLATION", "DETECT", "VERIFY", "ANTI", "AC_", "SUSPICIOUS", "ABNORMAL", "MONITOR", "TRACK", "TELEMETRY", "ANALYTICS", "CRASH", "DUMP"}
                    for _, be in ipairs(blocked) do
                        if eventID:find(be) then return end
                    end
                end
                if oldPost then oldPost(eventType, eventID, ...) end
            end
        end
        local logFuncs = {"log", "log_warning", "log_error", "log_shipping_client", "log_format", "log_tree"}
        for _, funcName in ipairs(logFuncs) do
            if _G[funcName] then
                _G[funcName] = function(...)
                    local args = {...}
                    for _, arg in ipairs(args) do
                        if type(arg) == "string" and (
                            arg:find("cheat") or arg:find("security") or arg:find("ban") or
                            arg:find("detect") or arg:find("verify") or arg:find("integrity") or
                            arg:find("report") or arg:find("violation") or arg:find("hack") or
                            arg:find("anti") or arg:find("ac_") or arg:find("suspicious") or
                            arg:find("abnormal") or arg:find("monitor") or arg:find("track")
                        ) then return end
                    end
                end
            end
        end
        if LogUtil then
            LogUtil.SetForceLog = function() end
            LogUtil.SetLogTreeEnable = function() end
            LogUtil.SetWriteLog = function() end
        end
        if sandbox then
            sandbox.LogError = function() end
            sandbox.LogWarning = function() end
        end
    end)
end

local function StartBypass_VIP_v4()
    pcall(function()
        ClientEntryBypass()
    end)
end

local TXtime_ticker = require('common.time_ticker')
_G.Mytimer_ticker = TXtime_ticker
if _G.Mytimer_ticker then
    pcall(function()
        _G.Mytimer_ticker.AddTimerLoop(2.0, StartBypass_VIP_v4, -1, 1)
    end)
end

)Ultimate_LUA_END";